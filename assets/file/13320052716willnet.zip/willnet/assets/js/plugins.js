$(document).ready(function(){
    
    // Tagsinput
    if($(".tags").length > 0)
        $(".tags").tagsInput({'width':'100%',
                              'height':'auto',
                              'onAddTag': function(text){
                                //action
                              },
                              'onRemoveTag': function(text){
                                //action
                              }});
});

$(window).load(function(){

    // custom scrollbar        
    if($(".scroll").length > 0)
        $(".scroll").mCustomScrollbar();
    // eof custom scrollbar    
    
});

$('.wrapper').resize(function(){

    if($("#wysiwyg").length > 0) editor.refresh();
    if($("#mail_wysiwyg").length > 0) m_editor.refresh();
    
});


