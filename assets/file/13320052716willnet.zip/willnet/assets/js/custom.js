/*
	Author: Umair Chaudary @ Pixel Art Inc.
	Author URI: http://www.pixelartinc.com/
*/


jQuery(document).ready(function($) {
	
	function open_nav(){
		$(".select h4").click(function(e){
			e.preventDefault();
			$(this).next('ul').stop(true, true).slideDown(500);
			$(this).addClass('close-nav');
			close_nav();
		});
	}
	open_nav();
	function close_nav(){
		$(".select .close-nav").click(function(e){
			e.preventDefault();
			$(this).next('ul').stop(true, true).slideUp(500);
			$(this).removeClass('close-nav');
			open_nav();
		});
	}
	
	//Dropdown Navigation
    function open_nav(){
        $(".responsive-nav .open > a").click(function(e){
            e.preventDefault();
            $(this).siblings('ul').stop(true, true).slideDown(500);
            $(this).removeClass('open').addClass('close-nav');
            close_nav();
        });
    }
    open_nav();
    function close_nav(){
        $(".responsive-nav .close-nav > a").click(function(e){
            e.preventDefault();
            $(this).siblings('ul').stop(true, true).slideUp(500);
            $(this).removeClass('close-nav').addClass('open');
            open_nav();
        });
    }

	
	//Lamg Nav
	function open_lang(){
		$(".language-section").click(function(e){
			e.preventDefault();
			$(this).children('ul').stop(true, true).slideDown(500);
			$(this).addClass('close-nav');
			close_lang();
		});
	}
	open_lang();
	function close_lang(){
		$(".language-section.close-nav").click(function(e){
			e.preventDefault();
			$(this).children('ul').stop(true, true).slideUp(500);
			$(this).removeClass('close-nav');
			open_lang();
		});
	}
	
					
    $( "#tabs" ).tabs();

    $( "#accordion" ).accordion();

    $('.fade').cycle({
         next:   '.next',
        prev:   '.prev'
    });
    $('.slide').cycle({
        next:   '.next-pic',
        prev:   '.prev-pic'
    });
	
	$('#work-carousel').carouFredSel({
        auto: true,
        prev: '.arrow-left',
        next: '.arrow-right'
    });
	
	$('#latest-work').carouFredSel({
        auto: true,
        prev: '.l-arrow-left',
        next: '.l-arrow-right',
        scroll: 1
	});
	
	$('#blog-sec').carouFredSel({
        auto: true,
        prev: '.arrow-left',
        next: '.arrow-right'
    });
	$('#testimonials').carouFredSel({
        auto: true,
        prev: '.te-arrow-left',
        next: '.te-arrow-right'
    });
	$('.clients-logo').carouFredSel({
        auto: true,
        prev: '.c-arrow-left',
        next: '.c-arrow-right',
		scroll: 1
    });
	$('#our-team').carouFredSel({
        auto: true,
        prev: '.te-arrow-left',
        next: '.te-arrow-right',
		scroll: 1
    });
	
	$(".zoom").prettyPhoto({
        social_tools: false
    }); 
	
	$("nav ul li").hover(function(){
			$(this).children("ul").stop(true,true).slideDown(800);
		},function(){
			$(this).children("ul").stop(true,true).slideUp(800);
	});
	
						
	// Isotops					
		var $container = $('#project-eliment');
	
			$container.isotope({
				itemSelector : '.item'
			});
	
			var $optionSets = $('.my-selector'),
	  			$optionLinks = $optionSets.find('a');
	
				$optionLinks.click(function(){
			var $this = $(this);
			if ( $this.hasClass('selected') ) {
	  			return false;
				}
		var $optionSet = $this.parents('.my-selector');
			$optionSet.find('.selected').removeClass('selected');
			$this.addClass('selected');
		var options = {},
			key = $optionSet.attr('data-option-key'),
			value = $this.attr('data-option-value');
			value = value === 'false' ? false : value;
		options[ key ] = value;
		if ( key === 'layoutMode' && typeof changeLayoutMode === 'function' ) {
	  		changeLayoutMode( $this, options )
			} else {
	  			$container.isotope( options );
			}
	
			return false;
		});	
	
						
});
