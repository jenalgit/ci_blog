<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Rss_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	function get_posts($count)
	{
		$query = $this->db->get('tbltutorial', $count)->result();
		return $query;
	}
	
}