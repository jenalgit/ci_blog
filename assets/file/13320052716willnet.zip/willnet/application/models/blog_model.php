<?php
class Blog_model extends CI_Model
	{
	
		function __constuct()
	{
		parent::__constuct();  // Call the Model constructor 
	}

		function Daftar_Kategori_Tutorial()
		{
			$query_kategori_tutorial=$this->db->query("select * from tblkategoritutorial");
			return $query_kategori_tutorial;
		}

		function Tampil_Tutorial()
		{
			$query_tutorial=$this->db->query("SELECT tbltutorial.id_tutorial, tbltutorial.judul_tutorial, tbltutorial.slug, tbltutorial.isi, tbltutorial.gambar, tbltutorial.waktu, tbltutorial.tanggal, tblkategoritutorial.id_kategori_tutorial, tblkategoritutorial.nama_kategori from tbltutorial left outer join tblkategoritutorial on tbltutorial.id_kategori_tutorial=tblkategoritutorial.id_kategori_tutorial order by id_tutorial DESC LIMIT 3");
			return $query_tutorial;

		}

		function Tampil_Portfolio()
		{
			$portfolio=$this->db->query("SELECT * from portfolio order by id DESC LIMIT 8");
			return $portfolio;
		}

		function Tampil_Client()
		{
			$client=$this->db->query("SELECT * FROM client order by id DESC LIMIT 12");
			return $client;
		}

		function Recent_Blog()
		{
			$query_blog=$this->db->query("SELECT tbltutorial.id_tutorial, tbltutorial.judul_tutorial, tbltutorial.slug, tbltutorial.isi, tbltutorial.gambar, tbltutorial.waktu, tbltutorial.tanggal, tblkategoritutorial.id_kategori_tutorial, tblkategoritutorial.nama_kategori from tbltutorial left outer join tblkategoritutorial on tbltutorial.id_kategori_tutorial=tblkategoritutorial.id_kategori_tutorial order by id_tutorial DESC LIMIT 2");
			return $query_blog;

		}

		function Total_Komentar_Tutorial($id_tutorial)
		{
			$query_detail_tutorial=$this->db->query("SELECT tbltutorial.judul_tutorial, tblkomentartutorial.id_komen_tutorial, tblkomentartutorial.nama, tblkomentartutorial.email, tblkomentartutorial.komentar, tblkomentartutorial.tanggal, tblkomentartutorial.waktu from tbltutorial left outer join tblkomentartutorial on tbltutorial.id_tutorial=tblkomentartutorial.id_tutorial where tbltutorial.id_tutorial='$id_tutorial'");
			return $query_detail_tutorial;
		}

		function Tampil_Komentar_Tutorial($id_tutorial,$ofset,$batas)
		{
			$query_tampil=$this->db->query("SELECT tbltutorial.judul_tutorial, tblkomentartutorial.id_komen_tutorial, tblkomentartutorial.nama, tblkomentartutorial.email, tblkomentartutorial.komentar, tblkomentartutorial.tanggal, tblkomentartutorial.waktu from tbltutorial left outer join tblkomentartutorial on tbltutorial.id_tutorial=tblkomentartutorial.id_tutorial where tbltutorial.id_tutorial='$id_tutorial' order by id_komen_tutorial DESC LIMIT $ofset,$batas");
			return $query_tampil;
		}

		function Simpan_Data($datainput)
		{
			$this->db->insert('tblkomentartutorial',$datainput);
		} 

		function Detail_Tutorial($id_tutorial)
		{
			$query_detail_tutorial=$this->db->query("SELECT tbltutorial.author, tbltutorial.id_tutorial, tbltutorial.judul_tutorial, tbltutorial.slug, tbltutorial.isi, tbltutorial.gambar, tbltutorial.waktu, tbltutorial.tanggal, tblkategoritutorial.nama_kategori, tblkategoritutorial.id_kategori_tutorial, tbltutorial.counter from tbltutorial left outer join
			tblkategoritutorial on tbltutorial.id_kategori_tutorial=tblkategoritutorial.id_kategori_tutorial where slug='$id_tutorial'");
			return $query_detail_tutorial;
		}

		function Judul_Kategori_Tutorial($id_kategori)
		{
			$query_kategori=$this->db->query("select * from tblkategoritutorial where id_kategori_tutorial='$id_kategori'");
			return $query_kategori;
		}

		function Kategori_Tutorial($id_kategori,$ofset,$batas)
		{
			$query_kat_tutorial=$this->db->query("SELECT tbltutorial.id_tutorial, tbltutorial.judul_tutorial, tbltutorial.slug, tbltutorial.isi, 
			tbltutorial.gambar, tbltutorial.waktu, tbltutorial.tanggal, tbltutorial.counter, tblkategoritutorial.nama_kategori from tbltutorial left outer join tblkategoritutorial on tbltutorial.id_kategori_tutorial=tblkategoritutorial.id_kategori_tutorial where tbltutorial.id_kategori_tutorial='$id_kategori' order by id_tutorial DESC LIMIT $ofset,$batas");
			return $query_kat_tutorial;
		}

		function Total_Tutorial($id_kategori)
		{
			$query_kat_tutorial=$this->db->query("SELECT tbltutorial.id_tutorial, tbltutorial.judul_tutorial, tbltutorial.slug, tbltutorial.isi, 
			tbltutorial.gambar, tbltutorial.waktu, tbltutorial.tanggal, tblkategoritutorial.nama_kategori from tbltutorial left outer join tblkategoritutorial on tbltutorial.id_kategori_tutorial=tblkategoritutorial.id_kategori_tutorial where tbltutorial.id_kategori_tutorial='$id_kategori' order by id_tutorial DESC");
			return $query_kat_tutorial;
		}

		function Tutorial_Acak($id_tutorial)
		{
			$query_tutorial=$this->db->query("SELECT * from tbltutorial where id_tutorial!='$id_tutorial' order by RAND() LIMIT 5");
			return $query_tutorial;
		}

		function Tampil_Polling()
		{
			$query_poll=$this->db->query("select * from tblsoalpolling where status='Y'");
			return $query_poll;
		}

		function Tampil_Soal_Polling($id_soal)
		{
			$query_soal=$this->db->query("select * from tbljawabanpoll where id_soal_poll='$id_soal'");
			return $query_soal;
		}

		function Tentang()
		{
			$query_tentang=$this->db->query("select * from about");
			return $query_tentang;
		}

		function Update_Counter_Tutorial($id_tutorial)
		{
			$query_update=$this->db->query("update tbltutorial set counter=counter+1 where slug='$id_tutorial'");
			return $query_update;
		}

		function Tutorial_Populer()
		{
			$query_populer=$this->db->query("select tbltutorial.id_tutorial, tbltutorial.judul_tutorial, tbltutorial.slug, tbltutorial.counter from 
			tbltutorial order by counter DESC limit 10");
			return $query_populer;
		}

		function Pencarian($kata_kunci,$tabel)
		{
			$query_cari=$this->db->query("select * from $tabel where isi like '%$kata_kunci%'");
			return $query_cari;
		}

		function Update_Polling($id_poll)
		{
			$query_update=$this->db->query("update tbljawabanpoll set counter=counter+1 where id_jawaban_poll='$id_poll'");
			return $query_update;
		}

		function Data_Login($user,$pass)
		{
			$user_bersih=mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($user,ENT_QUOTES))));
			$pass_bersih=mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($pass,ENT_QUOTES))));
			$query=$this->db->query("select * from tbllogin where username='$user_bersih' and psw=PASSWORD('$pass_bersih')");
			return $query;
		}

		function Contact($input)
		{
			$this->db->insert('tblinbox',$input);
		}

		function Detail_Pesan($user,$id_inbox)
		{
			$mentah=base64_decode($id_inbox);
			$pecah=explode("9002",$mentah);
			$id=$pecah[1];
			$daftar=$this->db->query("select * from tblinbox left join tbllogin on tblinbox.username=tbllogin.username where tblinbox.username='$user' and id_inbox='$id'");
			return $daftar;
		}

	}
?>
