<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin_model extends CI_Model
	{
		
		function __constuct()
		{
		parent::__constuct();  // Call the Model constructor 
		}
	
		#portfolio
		function Tampil_Portfolio($limit,$ofset)
		{
			$t=$this->db->query("select * from portfolio order by id DESC LIMIT $ofset,$limit");
			return $t;
		}

		function Total_Portfolio()
		{
			$t=$this->db->query("select * from portfolio");
			return $t;
		}

		function Edit_Portfolio($id)
		{
			$t=$this->db->query("select * from portfolio where id='$id'");
			return $t;
		}
		
		function Update_Portfolio($in)
		{
			$this->db->where('id',$in['id']);
			$this->db->update('portfolio',$in);
		}

		function Simpan_Portfolio($in)
		{
			$kat=$this->db->insert('portfolio',$in);
			return $kat;
		}

		function Hapus_Portfolio($id)
		{
			$this->db->where('id',$id);
			$this->db->delete('portfolio');
		}
		# end portfolio

		#clients
		function Tampil_Client($limit,$ofset)
		{
			$t=$this->db->query("select * from client order by id DESC LIMIT $ofset,$limit");
			return $t;
		}

		function Total_Client()
		{
			$t=$this->db->query("select * from client");
			return $t;
		}

		function Edit_Client($id)
		{
			$t=$this->db->query("select * from client where id='$id'");
			return $t;
		}
		
		function Update_Client($in)
		{
			$this->db->where('id',$in['id']);
			$this->db->update('client',$in);
		}

		function Simpan_Client($in)
		{
			$kat=$this->db->insert('client',$in);
			return $kat;
		}

		function Hapus_Client($id)
		{
			$this->db->where('id',$id);
			$this->db->delete('client');
		}
		# end clients

		#about
		function Tampil_About()
		{
			$t=$this->db->query("select * from about");
			return $t;
		}

		function Edit_About($id)
		{
			$t=$this->db->query("select * from about where id='$id'");
			return $t;
		}
		
		function Update_About($in)
		{
			$this->db->where('id',$in['id']);
			$this->db->update('about',$in);
		}
		#end

		function Komen_Berita($limit,$ofset)
		{
			$t=$this->db->query("select * from tblkomentarberita left join tblberita
			on tblkomentarberita.id_berita=tblberita.id_berita order by id_komen_berita DESC LIMIT $ofset,$limit");
			return $t;
		}
		function Total_Komen_Berita()
		{
			$t=$this->db->query("select * from tblkomentarberita");
			return $t;
		}
		function Hapus_Komen_Berita($id)
		{
			$this->db->where('id_komen_berita',$id);
			$this->db->delete('tblkomentarberita');
		}
		
		function Tampil_File($limit,$ofset)
		{
			$t=$this->db->query("select * from tbldownload left join tblkategoridownload on 	
			tbldownload.id_kat=tblkategoridownload.id_kategori_download order by id_download DESC LIMIT $ofset,$limit");
			return $t;
		}
		function Total_File()
		{
			$t=$this->db->query("select * from tbldownload left join tblkategoridownload on 	
			tbldownload.id_kat=tblkategoridownload.id_kategori_download");
			return $t;
		}
		function Kat_Down()
		{
			$kat=$this->db->query("select * from tblkategoridownload order by id_kategori_download DESC");
			return $kat;
		}
		function Simpan_Upload($in)
		{
			$kat=$this->db->insert('tbldownload',$in);
			return $kat;
		}
		function Edit_Upload($id)
		{
			$t=$this->db->query("select * from tbldownload left join tblkategoridownload on 	
			tbldownload.id_kat=tblkategoridownload.id_kategori_download where id_download='$id'");
			return $t;
		}
		function Update_Upload($in)
		{
			$this->db->where('id_download',$in['id_download']);
			$this->db->update('tbldownload',$in);
		}
		function Delete_Upload($id)
		{
			$this->db->where('id_download',$id);
			$this->db->delete('tbldownload');
		}
		function Simpan_Kat_Download($in)
		{
			$kat=$this->db->insert('tblkategoridownload',$in);
			return $kat;
		}
		function Edit_Kat_Download($id)
		{
			$t=$this->db->query("select * from tblkategoridownload where id_kategori_download='$id'");
			return $t;
		}
		function Update_Kat_Download($in)
		{
			$this->db->where('id_kategori_download',$in['id_kategori_download']);
			$this->db->update('tblkategoridownload',$in);
		}
		function Hapus_Kat_Download($id)
		{
			$this->db->where('id_kategori_download',$id);
			$this->db->delete('tblkategoridownload');
		}
		function Tampil_Tutorial($limit,$ofset)
		{
			$t=$this->db->query("select * from tbltutorial left join tblkategoritutorial on tbltutorial.id_kategori_tutorial=tblkategoritutorial.id_kategori_tutorial order by id_tutorial DESC LIMIT $ofset,$limit");
			return $t;
		}
		function Total_Tutorial()
		{
			$t=$this->db->query("select * from tbltutorial left join tblkategoritutorial on tbltutorial.id_kategori_tutorial=tblkategoritutorial.id_kategori_tutorial");
			return $t;
		}
		function Kat_Tutorial()
		{
			$kat=$this->db->query("select * from tblkategoritutorial");
			return $kat;
		}
		function Simpan_Tutorial($in)
		{
			$kat=$this->db->insert('tbltutorial',$in);
			return $kat;
		}
		function Edit_Tutorial($id)
		{
			$ed=$this->db->query("select * from tbltutorial left join tblkategoritutorial on tbltutorial.id_kategori_tutorial=tblkategoritutorial.id_kategori_tutorial where 				id_tutorial='$id'");
			return $ed;
		}
		function Update_Tutorial($in)
		{
			$this->db->where('id_tutorial',$in['id_tutorial']);
			$this->db->update('tbltutorial',$in);
		}
		function Delete_Tutorial($id)
		{
			$this->db->where('id_tutorial',$id);
			$this->db->delete('tbltutorial');
		}
		function Tampil_Kat_Tutorial($limit,$ofset)
		{
			$t=$this->db->query("select * from tblkategoritutorial order by id_kategori_tutorial DESC LIMIT $ofset,$limit");
			return $t;
		}
		function Simpan_Kat_Tutorial($in)
		{
			$kat=$this->db->insert('tblkategoritutorial',$in);
			return $kat;
		}
		function Edit_Kat_Tutorial($id)
		{
			$t=$this->db->query("select * from tblkategoritutorial where id_kategori_tutorial='$id'");
			return $t;
		}
		function Update_Kat_Tutorial($in)
		{
			$this->db->where('id_kategori_tutorial',$in['id_kategori_tutorial']);
			$this->db->update('tblkategoritutorial',$in);
		}
		function Hapus_Kat_Tutorial($id)
		{
			$this->db->where('id_kategori_tutorial',$id);
			$this->db->delete('tblkategoritutorial');
		}
		function Tampil_Inbox($user,$limit,$ofset)
		{
			$t=$this->db->query("select * from tblinbox order by id_inbox DESC LIMIT $ofset,$limit");
			return $t;
		}
		function Total_Inbox($user)
		{
			$t=$this->db->query("select * from tblinbox");
			return $t;
		}
		function Detail_Inbox($user,$id)
		{
			$mentah=base64_decode($id);
			$pecah=explode("9002",$mentah);
			$id2=$pecah[1];
			$t=$this->db->query("select * from tblinbox where id_inbox='$id2'");
			return $t;
		}
		function Update_Pesan($id_inbox)
		{
			$mentah=base64_decode($id_inbox);
			$pecah=explode("9002",$mentah);
			$id=$pecah[1];
			$this->db->query("update tblinbox set status_pesan='Y' where id_inbox='$id'");
		}
		function Balas_Pesan($in)
		{
			$kat=$this->db->insert('tblinbox',$in);
			return $kat;
		}
		function Update_Pesan_Lama($pesan,$id)
		{
		$u=$this->db->query("update tblinbox set pesan='$pesan' where id_inbox='$id'");
		return $u;
		}
		function Delete_Pesan($id_in)
		{
			$mentah=base64_decode($id_in);
			$pecah=explode("9002",$mentah);
			$id=$pecah[1];
			$this->db->where('id_inbox',$id);
			$this->db->delete('tblinbox');
		}
	}
