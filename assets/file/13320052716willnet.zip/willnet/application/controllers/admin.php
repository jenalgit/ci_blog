<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url', 'text_helper','date','file'));
		$this->load->database();
		session_start();
	}
	
	function index()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/isi_index',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}
	
	#portfolio
	function portfolio()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
			$page=$this->uri->segment(3);
      		$limit_ti=15;
			if(!$page):
			$offset_ti = 0;
			else:
			$offset_ti = $page;
			endif;
			$this->load->model('Admin_model');
			$this->load->library('Pagination');
			$query=$this->Admin_model->Tampil_Portfolio($limit_ti,$offset_ti);
			$tot_hal = $this->Admin_model->Total_Portfolio();
      		$config['base_url'] = base_url() . '/admin/portfolio';
       		$config['total_rows'] = $tot_hal->num_rows();
			$config['per_page'] = $limit_ti;
			$config['uri_segment'] = 3;
			$config['first_link'] = 'Awal';
			$config['last_link'] = 'Akhir';
			$config['next_link'] = 'Selanjutnya';
			$config['prev_link'] = 'Sebelumnya';
			$this->pagination->initialize($config);
			$paginator=$this->pagination->create_links();
	   		$data['scriptmce'] = $this->scripttiny_mce();
        	$data_isi = array('query' => $query,'paginator'=>$paginator, 'page'=>$page);
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/portfolio',$data_isi);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function editportfolio()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$page=$this->uri->segment(3);
			$this->load->model('Admin_model');
			$data['det']=$this->Admin_model->Edit_Portfolio($id);
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/edit_portfolio',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function updateportfolio()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
			$config['upload_path'] = './assets/portfolio/';
			$config['allowed_types'] ='bmp|gif|jpg|jpeg|png';
			$config['max_size'] = '10000';
			$config['max_width'] = '2000';
			$config['max_height'] = '2000';						
			$this->load->library('upload', $config);
		
			if(empty($_FILES['userfile']['name'])){
				$in["nama"]=$this->input->post('judul');
				$in["isi"]=$this->input->post('isi');
				$in["id"]=$this->input->post('id');
				$this->Admin_model->Update_Portfolio($in);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/portfolio'>";
				
			}
			else{
				if(!$this->upload->do_upload())
				{
			 	echo $this->upload->display_errors();
				}
				else {
				$in2["nama"]=$this->input->post('judul');
				$in2["isi"]=$this->input->post('isi');
				$in2["id"]=$this->input->post('id');
				$in2["gambar"]=$_FILES['userfile']['name'];
				$this->Admin_model->Update_Portfolio($in2);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/portfolio'>";
				}
			}

			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function tambahportfolio()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/tambah_portfolio',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function simpanportfolio()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$tgl = " %Y-%m-%d";
			$jam = "%h:%i:%a";
			$time = time();
			$in=array();
			if(empty($_FILES['userfile']['name'])){
			$in['nama']=$this->input->post('judul');
			$in['isi']=$this->input->post('isi');
			$in['gambar']="gbr-news.jpg";
			$in["tanggal"] = mdate($tgl,$time);
			$this->Admin_model->Simpan_Portfolio($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/portfolio'>";
			}
			else{
			$in['nama']=$this->input->post('judul');
			$in['isi']=$this->input->post('isi');
			$in['gambar']=$_FILES['userfile']['name'];
			$in["tanggal"] = mdate($tgl,$time);
			
			$config['upload_path'] = './assets/portfolio/';
			$config['allowed_types'] = 'bmp|gif|jpg|jpeg|png';
			$config['max_size'] = '10000';
			$config['max_width'] = '2000';
			$config['max_height'] = '2000';						
			$this->load->library('upload', $config);
		
			if(!$this->upload->do_upload())
			{
			 echo $this->upload->display_errors();
			}
			else {
			$this->Admin_model->Simpan_Portfolio($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/portfolio'>";
			}
			}
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function hapusportfolio()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$this->load->model('Admin_model');
			$hapus=$this->Admin_model->Edit_Portfolio($id);
			foreach($hapus->result() as $t)
			{
				unlink("./assets/portfolio/$t->gambar");
			}
			$this->Admin_model->Hapus_Portfolio($id);
			
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/portfolio'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}
	#end

	#client
	function client()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
			$page=$this->uri->segment(3);
      		$limit_ti=15;
			if(!$page):
			$offset_ti = 0;
			else:
			$offset_ti = $page;
			endif;
			$this->load->model('Admin_model');
			$this->load->library('Pagination');
			$query=$this->Admin_model->Tampil_Client($limit_ti,$offset_ti);
			$tot_hal = $this->Admin_model->Total_Client();
      		$config['base_url'] = base_url() . '/admin/client';
       		$config['total_rows'] = $tot_hal->num_rows();
			$config['per_page'] = $limit_ti;
			$config['uri_segment'] = 3;
			$config['first_link'] = 'Awal';
			$config['last_link'] = 'Akhir';
			$config['next_link'] = 'Selanjutnya';
			$config['prev_link'] = 'Sebelumnya';
			$this->pagination->initialize($config);
			$paginator=$this->pagination->create_links();
	   		$data['scriptmce'] = $this->scripttiny_mce();
        	$data_isi = array('query' => $query,'paginator'=>$paginator, 'page'=>$page);
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/client',$data_isi);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function editclient()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$page=$this->uri->segment(3);
			$this->load->model('Admin_model');
			$data['det']=$this->Admin_model->Edit_Client($id);
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/edit_client',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function updateclient()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
			$config['upload_path'] = './assets/client/';
			$config['allowed_types'] ='bmp|gif|jpg|jpeg|png';
			$config['max_size'] = '10000';
			$config['max_width'] = '2000';
			$config['max_height'] = '2000';						
			$this->load->library('upload', $config);
		
			if(empty($_FILES['userfile']['name'])){
				$in["nama"]=$this->input->post('judul');
				$in["id"]=$this->input->post('id');
				$this->Admin_model->Update_Client($in);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/client'>";
				
			}
			else{
				if(!$this->upload->do_upload())
				{
			 	echo $this->upload->display_errors();
				}
				else {
				$in2["nama"]=$this->input->post('judul');
				$in2["id"]=$this->input->post('id');
				$in2["gambar"]=$_FILES['userfile']['name'];
				$this->Admin_model->Update_Client($in2);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/client'>";
				}
			}

			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function tambahclient()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/tambah_client',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function simpanclient()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$tgl = " %Y-%m-%d";
			$jam = "%h:%i:%a";
			$time = time();
			$in=array();
			if(empty($_FILES['userfile']['name'])){
			$in['nama']=$this->input->post('judul');
			$in['gambar']="gbr-news.jpg";
			$this->Admin_model->Simpan_Client($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/client'>";
			}
			else{
			$in['nama']=$this->input->post('judul');
			$in['gambar']=$_FILES['userfile']['name'];
			
			$config['upload_path'] = './assets/client/';
			$config['allowed_types'] = 'bmp|gif|jpg|jpeg|png';
			$config['max_size'] = '10000';
			$config['max_width'] = '2000';
			$config['max_height'] = '2000';						
			$this->load->library('upload', $config);
		
			if(!$this->upload->do_upload())
			{
			 echo $this->upload->display_errors();
			}
			else {
			$this->Admin_model->Simpan_Client($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/client'>";
			}
			}
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function hapusclient()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$this->load->model('Admin_model');
			$hapus=$this->Admin_model->Edit_Client($id);
			foreach($hapus->result() as $t)
			{
				unlink("./assets/client/$t->gambar");
			}
			$this->Admin_model->Hapus_Client($id);
			
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/client'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}
	#end
	
	#about
	function about()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
			$pecah=explode("|", $session);
			$data["nim"]=$pecah[0];
			$data["nama"]=$pecah[1];
			$data["status"]=$pecah[3];
			$data["scriptmce"] = $this->scripttiny_mce();
			if($data["status"]=="admin"){
				$this->load->model('Admin_model');
				$data["query"]=$this->Admin_model->Tampil_About();

				$this->load->view('admin/bg_head',$data);
				$this->load->view('admin/about',$data);
				$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0 url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function editabout()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$page=$this->uri->segment(3);
			$this->load->model('Admin_model');
			$data['det']=$this->Admin_model->Edit_About($id);
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/edit_about',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function updateabout()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
		
				$in["isi"]=$this->input->post('isi');
				$in["id"]=$this->input->post('id');
				$this->Admin_model->Update_About($in);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/about'>";

			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}
	#end

	function komenberita()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data=array();
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
			$page=$this->uri->segment(3);
      		$limit_ti=15;
			if(!$page):
			$offset_ti = 0;
			else:
			$offset_ti = $page;
			endif;
			$this->load->model('Admin_model');
			$this->load->library('Pagination');
			$query=$this->Admin_model->Komen_Berita($limit_ti,$offset_ti);
			$tot_hal = $this->Admin_model->Total_Komen_Berita();
      		$config['base_url'] = base_url() . '/admin/komenberita';
       		$config['total_rows'] = $tot_hal->num_rows();
			$config['per_page'] = $limit_ti;
			$config['uri_segment'] = 3;
			$config['first_link'] = 'Awal';
			$config['last_link'] = 'Akhir';
			$config['next_link'] = 'Selanjutnya';
			$config['prev_link'] = 'Sebelumnya';
			$this->pagination->initialize($config);
			$paginator=$this->pagination->create_links();
	   		$data['scriptmce'] = $this->scripttiny_mce();
        	$data_isi = array('query' => $query,'paginator'=>$paginator, 'page'=>$page);
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/komen_berita',$data_isi);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function hapuskomenberita()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$this->load->model('Admin_model');
			$this->Admin_model->Hapus_Komen_Berita($id);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/komenberita'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}
	
	function upload()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data=array();
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
			$page=$this->uri->segment(3);
      		$limit_ti=15;
			if(!$page):
			$offset_ti = 0;
			else:
			$offset_ti = $page;
			endif;
			$this->load->model('Admin_model');
			$this->load->library('Pagination');
			$query=$this->Admin_model->Tampil_File($limit_ti,$offset_ti);
			$tot_hal = $this->Admin_model->Total_File();
      		$config['base_url'] = base_url() . '/admin/upload';
       		$config['total_rows'] = $tot_hal->num_rows();
			$config['per_page'] = $limit_ti;
			$config['uri_segment'] = 3;
			$config['first_link'] = 'Awal';
			$config['last_link'] = 'Akhir';
			$config['next_link'] = 'Selanjutnya';
			$config['prev_link'] = 'Sebelumnya';
			$this->pagination->initialize($config);
			$paginator=$this->pagination->create_links();
	   		$data['scriptmce'] = $this->scripttiny_mce();
        	$data_isi = array('query' => $query,'paginator'=>$paginator, 'page'=>$page);
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/upload',$data_isi);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function tambahupload()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data=array();
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$data["kat"]=$this->Admin_model->Kat_Down();
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/tambah_upload',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}
	function simpanupload()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
			$tgl = " %Y-%m-%d";
			$jam = "%h:%i:%a";
			$time = time();
			$in["tgl_posting"] = mdate($tgl,$time);
			$in["judul_file"]=$this->input->post('judul');
			$in["author"]=$nim;
			$in["id_kat"]=$this->input->post('kategori');
			$acak=rand(00000000000,99999999999);
			$bersih=$_FILES['userfile']['name'];
			$nm=str_replace(" ","_","$bersih");
			$pisah=explode(".",$nm);
			$nama_murni=$pisah[0];
			$ubah=$acak.$nama_murni; //tanpa ekstensi
			$config["file_name"]=$ubah; //dengan eekstensi
			$in["nama_file"]=$acak.$nm;
			$config['upload_path'] = './assets/download/';
			$config['allowed_types'] = 'exe|sql|psd|pdf|xls|ppt|php|php4|php3|js|swf|Xhtml|zip|mid|midi|mp2|mp3|wav|bmp|gif|jpg|jpeg|png|html|htm|txt|rtf|mpeg|mpg|avi|doc|docx|xlsx';
			$config['max_size'] = '50000';
			$config['max_width'] = '400';
			$config['max_height'] = '300';						
			$this->load->library('upload', $config);
		
			if(!$this->upload->do_upload())
			{
			 echo $this->upload->display_errors();
			}
			else {
			$this->Admin_model->Simpan_Upload($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/upload'>";
			}

			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function editupload()
	{
		$datestring = "Login : %d-%m-%Y pukul %h:%i %a";
		$time = time();
		$data = array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
			if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$data["kategori"]=$this->Admin_model->Edit_Upload($id);
			$data["cur_kat"]=$this->Admin_model->Kat_Down();
			$data["tanggal"] = mdate($datestring, $time);
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/edit_upload',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function updateupload()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
			$config['upload_path'] = './assets/download/';
			$config['allowed_types'] = 'exe|sql|psd|pdf|xls|ppt|php|php4|php3|js|swf|Xhtml|zip|mid|midi|mp2|mp3|wav|bmp|gif|jpg|jpeg|png|html|htm|txt|rtf|mpeg|mpg|avi|doc|docx|xlsx';
			$config['max_size'] = '10000';
			$config['max_width'] = '400';
			$config['max_height'] = '300';
				$acak=rand(00000000000,99999999999);
				$bersih=$_FILES['userfile']['name'];
				$nm=str_replace(" ","_","$bersih");
				$pisah=explode(".",$nm);
				$nama_murni=$pisah[0];
				$ubah=$acak.$nama_murni; //tanpa ekstensi
				$config["file_name"]=$ubah; //dengan eekstensi
				$in2["nama_file"]=$acak.$nm;			
			$this->load->library('upload', $config);
		
			if(empty($_FILES['userfile']['name'])){
				$in["judul_file"]=$this->input->post('judul');
				$in["id_download"]=$this->input->post('id_download');
				$in["id_kat"]=$this->input->post('kategori');
				$this->Admin_model->Update_Upload($in);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/upload'>";
				
			}
			else{
				if(!$this->upload->do_upload())
				{
			 	echo $this->upload->display_errors();
				}
				else {
				$in2["judul_file"]=$this->input->post('judul');
				$in2["id_download"]=$this->input->post('id_download');
				$in2["id_kat"]=$this->input->post('kategori');

				$this->Admin_model->Update_Upload($in2);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/upload'>";
				}
			}

			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function hapusupload()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			if($status=="admin"){
			$this->load->model('Admin_model');
			$hapus=$this->Admin_model->Edit_Upload($id);
			foreach($hapus->result() as $t)
			{
				unlink("./assets/download/$t->nama_file");
			}
			$this->Admin_model->Delete_Upload($id);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/upload'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Anda tidak berhak masuk ke Control Panel Dosen...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function katdownload()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data=array();
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$this->load->library('Pagination');
			$data['kategori']=$this->Admin_model->Kat_Down();
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/kat_download',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}
	function tambahkatdownload()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data=array();
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/tambah_kat_download',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function simpankatdownload()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$in=array();
			$in['nama_kategori_download']=$this->input->post('nama');
			$this->Admin_model->Simpan_Kat_Download($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/katdownload'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function editkatdownload()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$this->load->model('Admin_model');
			$data['det']=$this->Admin_model->Edit_Kat_Download($id);
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/edit_kat_download',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function updatekatdownload()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
			$in=array();
			$in['id_kategori_download']=$this->input->post('id_kat');
			$in['nama_kategori_download']=$this->input->post('nama');
			$this->Admin_model->Update_Kat_Download($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/katdownload'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function hapuskatdownload()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$this->load->model('Admin_model');
			$this->Admin_model->Hapus_Kat_Download($id);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/katdownload'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function tutorial()
	{
		$datestring = "Login : %d-%m-%Y pukul %h:%i %a";
		$time = time();
		$data = array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
			if($data["status"]=="admin"){
		$data["tanggal"] = mdate($datestring, $time);
		$this->load->model('Admin_model');
		$this->load->library('Pagination');	
		$page=$this->uri->segment(3);
      		$limit_ti=15;
		if(!$page):
		$offset_ti = 0;
		else:
		$offset_ti = $page;
		endif;
		$query=$this->Admin_model->Tampil_Tutorial($limit_ti,$offset_ti);
		$tot_hal = $this->Admin_model->Total_Tutorial();
      		$config['base_url'] = base_url() . 'admin/tutorial';
       		$config['total_rows'] = $tot_hal->num_rows();
		$config['per_page'] = $limit_ti;
		$config['uri_segment'] = 3;
		$config['first_link'] = 'Awal';
		$config['last_link'] = 'Akhir';
		$config['next_link'] = 'Selanjutnya';
		$config['prev_link'] = 'Sebelumnya';
		$this->pagination->initialize($config);
		$paginator=$this->pagination->create_links();
	   	$data['scriptmce'] = $this->scripttiny_mce();
        	$data_isi = array('query' => $query,'paginator'=>$paginator, 'page'=>$page);
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/tutorial',$data_isi);
			$this->load->view('admin/bg_bawah');
			}
					else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Anda tidak berhak masuk ke Control Panel Dosen...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function tambahtutorial()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$data['kategori']=$this->Admin_model->Kat_Tutorial();
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/tambah_tutorial',$data);
			$this->load->view('admin/bg_bawah');

			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function simpantutorial()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
			$tgl = " %Y-%m-%d";
			$jam = "%h:%i:%a";
			$time = time();
			if(empty($_FILES['userfile']['name'])){
			$in["tanggal"] = mdate($tgl,$time);
			$in["waktu"] = mdate($jam,$time);
			$in["judul_tutorial"]=$this->input->post('judul');
			$in["slug"]=$this->input->post('slug');
			$in["isi"]=$this->input->post('isi');
			$in["tags"]=$this->input->post('tags');
			$in["author"]=$nim;
			$in["id_kategori_tutorial"]=$this->input->post('kategori');
			$in["counter"]=0;
			$in["gambar"]="gbr-tutor.jpg";
			$this->Admin_model->Simpan_Tutorial($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/tutorial'>";
			}
			else{
			$in["tanggal"] = mdate($tgl,$time);
			$in["waktu"] = mdate($jam,$time);
			$in["judul_tutorial"]=$this->input->post('judul');
			$in["slug"]=$this->input->post('slug');
			$in["isi"]=$this->input->post('isi');
			$in["tags"]=$this->input->post('tags');
			$in["author"]=$nim;
			$in["id_kategori_tutorial"]=$this->input->post('kategori');
			$in["counter"]=0;
			$in["gambar"]=$_FILES['userfile']['name'];
			$config['upload_path'] = './assets/tutorial/';
			$config['allowed_types'] = 'bmp|gif|jpg|jpeg|png';
			$config['max_size'] = '10000';
			$config['max_width'] = '400';
			$config['max_height'] = '300';						
			$this->load->library('upload', $config);
		
			if(!$this->upload->do_upload())
			{
			 echo $this->upload->display_errors();
			}
			else {
			$this->Admin_model->Simpan_Tutorial($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/tutorial'>";
			}
			}

			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function edittutorial()
	{
		$datestring = "Login : %d-%m-%Y pukul %h:%i %a";
		$time = time();
		$data = array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
			if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$data["kategori"]=$this->Admin_model->Edit_Tutorial($id);
			$data["cur_kat"]=$this->Admin_model->Kat_Tutorial();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/edit_tutorial',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function updatetutorial()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
			$config['upload_path'] = './assets/tutorial/';
			$config['allowed_types'] = 'exe|sql|psd|pdf|xls|ppt|php|php4|php3|js|swf|Xhtml|zip|mid|midi|mp2|mp3|wav|bmp|gif|jpg|jpeg|png|html|htm|txt|rtf|mpeg|mpg|avi|doc|docx|xlsx';
			$config['max_size'] = '10000';
			$config['max_width'] = '20000';
			$config['max_height'] = '20000';						
			$this->load->library('upload', $config);
		
			if(empty($_FILES['userfile']['name'])){
				$in["judul_tutorial"]=$this->input->post('judul');
				$in["slug"]=$this->input->post('slug');
				$in["isi"]=$this->input->post('isi_tutorial');
				$in["tags"]=$this->input->post('tags');
				$in["id_tutorial"]=$this->input->post('id_tutorial');
				$in["author"]=$nim;
				$in["id_kategori_tutorial"]=$this->input->post('kategori');
				$this->Admin_model->Update_Tutorial($in);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/tutorial'>";
				
			}
			else{
				if(!$this->upload->do_upload())
				{
			 	echo $this->upload->display_errors();
				}
				else {
				$in2["judul_tutorial"]=$this->input->post('judul');
				$in2["slug"]=$this->input->post('slug');
				$in2["isi"]=$this->input->post('isi_tutorial');
				$in2["tags"]=$this->input->post('tags');
				$in2["id_tutorial"]=$this->input->post('id_tutorial');
				$in2["author"]=$nim;
				$in2["gambar"]=$_FILES['userfile']['name'];
				$in2["id_kategori_tutorial"]=$this->input->post('kategori');
				$this->Admin_model->Update_Tutorial($in2);
				echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/tutorial'>";
				}
			}

			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function hapustutorial()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			if($status=="admin"){
			$this->load->model('Admin_model');
			$hapus=$this->Admin_model->Edit_Tutorial($id);
			foreach($hapus->result() as $t)
			{
				unlink("./assets/tutorial/$t->gambar");
			}
			$this->Admin_model->Delete_Tutorial($id);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/tutorial'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function inbox()
	{
		$datestring = "Login : %d-%m-%Y pukul %h:%i %a";
		$time = time();
		$data = array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
			if($data["status"]=="admin"){
		$data["tanggal"] = mdate($datestring, $time);
		$this->load->model('Admin_model');
		$this->load->library('Pagination');	
		$page=$this->uri->segment(3);
      		$limit_ti=15;
		if(!$page):
		$offset_ti = 0;
		else:
		$offset_ti = $page;
		endif;
		$query=$this->Admin_model->Tampil_Inbox($data["nim"],$limit_ti,$offset_ti);
		$tot_hal = $this->Admin_model->Total_Inbox($data["nim"]);
      		$config['base_url'] = base_url() . '/admin/inbox';
       		$config['total_rows'] = $tot_hal->num_rows();
		$config['per_page'] = $limit_ti;
		$config['uri_segment'] = 3;
		$config['first_link'] = 'Awal';
		$config['last_link'] = 'Akhir';
		$config['next_link'] = 'Selanjutnya';
		$config['prev_link'] = 'Sebelumnya';
		$this->pagination->initialize($config);
		$paginator=$this->pagination->create_links();
	   	$data['scriptmce'] = $this->scripttiny_mce();
        	$data_isi = array('query' => $query,'paginator'=>$paginator, 'page'=>$page);
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/inbox',$data_isi);
			$this->load->view('admin/bg_bawah');
			}
					else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function hapusinbox()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			if($status=="admin"){
			$this->load->model('Admin_model');
			$this->Admin_model->Delete_Pesan($id);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/inbox'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function kattutorial()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data=array();
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		$page=$this->uri->segment(3);
      		$limit_ti=15;
		if(!$page):
		$offset_ti = 0;
		else:
		$offset_ti = $page;
		endif;
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$this->load->library('Pagination');
			$data['kategori']=$this->Admin_model->Tampil_Kat_Tutorial($limit_ti,$offset_ti);
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/kat_tutorial',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>

			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function tambahkattutorial()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data=array();
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
	   	$data['scriptmce'] = $this->scripttiny_mce();
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/tambah_kat_tutorial',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function simpankattutorial()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
			$this->load->model('Admin_model');
			$in=array();
			$in['nama_kategori']=$this->input->post('nama');
			$this->Admin_model->Simpan_Kat_Tutorial($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/kattutorial'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function editkattutorial()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$this->load->model('Admin_model');
			$data['det']=$this->Admin_model->Edit_Kat_Tutorial($id);
	   		$data['scriptmce'] = $this->scripttiny_mce();
			$this->load->view('admin/bg_head',$data);
			$this->load->view('admin/edit_kat_tutorial',$data);
			$this->load->view('admin/bg_bawah');
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function updatekattutorial()
	{
		$in=array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$nim=$pecah[0];
		$status=$pecah[3];
			if($status=="admin"){
			$this->load->model('Admin_model');
			$in=array();
			$in['id_kategori_tutorial']=$this->input->post('id_kat');
			$in['nama_kategori']=$this->input->post('nama');
			$this->Admin_model->Update_Kat_Tutorial($in);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/kattutorial'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
		else{
			?>
			<script type="text/javascript" language="javascript">
			alert("Log In dulu dong...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

	function hapuskattutorial()
	{
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$data = array();
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		$data["status"]=$pecah[3];
		if($data["status"]=="admin"){
		$id='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id='';
		}
		else
		{
    			$id = $this->uri->segment(3);
		}
			$this->load->model('Admin_model');
			$this->Admin_model->Hapus_Kat_Tutorial($id);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."admin/kattutorial'>";
			}
			else{
			?>
			<script type="text/javascript" language="javascript">
			alert("You Don't Access Control Panel Admin...!!!");
			</script>
			<?php
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
		}
			else{
			?>
			<script type="text/javascript" language="javascript">
		alert("Log In dulu dong...!!!");
		</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."'>";
			}
	}

//Function TinyMce------------------------------------------------------------------
		private function scripttiny_mce($selectcategory=null) {
		return '
		<!-- TinyMCE -->
		<script type="text/javascript" src="'.base_url().'jscripts/tiny_mce/tiny_mce_src.js"></script>
		<script type="text/javascript">
		tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "advanced",
		plugins : "pagebreak,style,layer,table,save,advhr,advimage,syntaxhl,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",

		// Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,syntaxhl,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// Example content CSS (should be your site CSS)
		content_css : "'.base_url().'application/views/themes/css/BrightSide.css",

		// Drop lists for link/image/media/template dialogs
		//"'.base_url().'media/lists/image_list.js"
		template_external_list_url : "lists/template_list.js",
		external_link_list_url : "lists/link_list.js",
		external_image_list_url : "'.base_url().'index.php/",
		media_external_list_url : "lists/media_list.js",

		// Style formats
		style_formats : [
			{title : \'Bold text\', inline : \'b\'},
			{title : \'Red text\', inline : \'span\', styles : {color : \'#ff0000\'}},
			{title : \'Red header\', block : \'h1\', styles : {color : \'#ff0000\'}},
			{title : \'Example 1\', inline : \'span\', classes : \'example1\'},
			{title : \'Example 2\', inline : \'span\', classes : \'example2\'},
			{title : \'Table styles\'},
			{title : \'Table row 1\', selector : \'tr\', classes : \'tablerow1\'}
		],

		// Replace values for the template plugin
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});
</script>';	
	} 
}
