<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Welcome extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Blog_model');
		session_start();
	}

	function index()
	{
		$data["title"] = "Home - Design.willnethosting.com";
		$data["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();
		$data["portfolio"] = $this->Blog_model->Tampil_Portfolio();
		$data["tampil_tutorial"] = $this->Blog_model->Recent_Blog();
		$data["client"] = $this->Blog_model->Tampil_Client();

		$this->load->view('template/header',$data);
		$this->load->view('template/slide');
		$this->load->view('template/center',$data);
		$this->load->view('template/client',$data);
		$this->load->view('template/footer');
	}
}