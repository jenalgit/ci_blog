<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Blog extends CI_Controller {
	
	function __construct()

	{
		parent::__construct();
		session_start();
	}
	
	function index()

	{
	  $id_tutorial='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id_tutorial='';
		}
		else
		{
    			$id_tutorial = $this->uri->segment(3);
		}
		$data=array();
		$this->load->model('Blog_model');
		$data["title"] = "Blog - Design.willnethosting.com";
		$data["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();
		$data["tampil_tutorial"] = $this->Blog_model->Tampil_Tutorial();
		$data["tutorial_populer"] = $this->Blog_model->Tutorial_Populer();
		$data["acak_tutorial"] = $this->Blog_model->Tutorial_Acak($id_tutorial);

		$this->load->view('template/header',$data);
		$this->load->view('template/sidebar',$data);
		$this->load->view('template/content',$data);
		$this->load->view('template/footer');
	}

	function detail()

	{
		$id_tutorial='';		
		if ($this->uri->segment(3) === FALSE)
		{
    			$id_tutorial='';
		}
		else
		{
    			$id_tutorial = $this->uri->segment(3);
		}
		$data=array();
		$this->load->model('Blog_model');
		$this->load->library('Pagination');
		$data["detail"]=$this->Blog_model->Detail_Tutorial($id_tutorial);
		$data["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();
		$data["tutorial_populer"] = $this->Blog_model->Tutorial_Populer();
		$this->Blog_model->Update_Counter_Tutorial($id_tutorial);

		//Paging untuk komentar
     		$page=$this->uri->segment(4);
      		$limit=5;
		if(!$page):
		$offset = 0;
		else:
		$offset = $page;
		endif;

        	$data["query"] = $this->Blog_model->Tampil_Komentar_Tutorial($id_tutorial,$offset,$limit);
		    $tot_hal = $this->Blog_model->Total_Komentar_Tutorial($id_tutorial);
      	 	$config['base_url'] = base_url() . '/blog/detail/'.$id_tutorial;
        	$config['total_rows'] = $tot_hal->num_rows();
        	$config['per_page'] = $limit;
			$config['uri_segment'] = 4;
	    	$config['first_link'] = 'Awal';
			$config['last_link'] = 'Akhir';
			$config['next_link'] = 'Selanjutnya';
			$config['prev_link'] = 'Sebelumnya';
       		$this->pagination->initialize($config);
		$data["paginator"] =$this->pagination->create_links();
		//paging selesai

		$captcha_result = '';
    		$data["cap_img"] = $this -> _make_captcha();
    		if ( $this -> input -> post( 'submit' ) ) {
      			if ( $this -> _check_capthca() ) {
        		$captcha_result = 'GOOD';
      			}else {
        		$captcha_result = 'BAD';
      			}
    		}
   		$data["cap_msg"] = $captcha_result;

		$data["acak_tutorial"] = $this->Blog_model->Tutorial_Acak($id_tutorial);
		$data1 = $this->Blog_model->Detail_Tutorial($id_tutorial);
		foreach($data1->result() as $dp)
		{
			$judul = $dp->judul_tutorial;
		}
		$data["title"] = $judul." - Blog - Design.willnethosting.com"; 

		$this->load->view('template/header',$data);
		$this->load->view('template/sidebar1',$data);
		$this->load->view('template/detail',$data);
		$this->load->view('template/footer');
	}

	function category()

	{
		$id_kategori='';
		if ($this->uri->segment(3) === FALSE)
		{
    			$id_kategori='';
		}
		else
		{
    			$id_kategori = $this->uri->segment(3);
		}
		$data2=array();
		$this->load->model('Blog_model');
		$this->load->library('Pagination');
		$data1 = $this->Blog_model->Judul_Kategori_Tutorial($id_kategori);
		foreach($data1->result() as $dp)
		{
			$judul = 'Kategori ' .$dp->nama_kategori;
		}
		$data2["title"] = strtolower($judul)." - Blog - Design.willnethosting.com";
		$data2["judul_kategori"] = $this->Blog_model->Judul_Kategori_Tutorial($id_kategori);
		$data2["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();
		$data2["tutorial_populer"] = $this->Blog_model->Tutorial_Populer();

     	$page=$this->uri->segment(4);
      	$limit=12;
		if(!$page):
		$offset = 0;
		else:
		$offset = $page;
		endif;	
	
        $query = $this->Blog_model->Kategori_Tutorial($id_kategori,$offset,$limit);
		$tot_hal = $this->Blog_model->Total_Tutorial($id_kategori);
      	$config['base_url'] = base_url() . '/blog/category/'.$id_kategori;
        $config['total_rows'] = $tot_hal->num_rows();
        $config['per_page'] = $limit;
		$config['uri_segment'] = 4;
	    $config['first_link'] = 'Awal';
		$config['last_link'] = 'Akhir';
		$config['next_link'] = 'Selanjutnya';
		$config['prev_link'] = 'Sebelumnya';
        $this->pagination->initialize($config);
		$paginator=$this->pagination->create_links();

        $data = array('query' => $query,'paginator'=>$paginator);
		
		$this->load->view('template/header',$data2);
		$this->load->view('template/category',$data);
		$this->load->view('template/footer');
	}

	function kirimkomentar()

	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('email','Email','trim|required|valid_email');
		$this->form_validation->set_rules('komentar','Komentar','required');
		$this->form_validation->set_rules('captcha','Captcha','callback__check_capthca');
		$id_tutorial=$this->input->post('id_tutorial');
		$nama_non=$this->input->post('nama');
		$email_non=$this->input->post('email');
		$komentar_non=$this->input->post('komentar');
		$nama=strip_tags($nama_non);
		$email=strip_tags($email_non);
		$komentar=strip_tags($komentar_non);
			$tgl = " %Y-%m-%d";
			$jam = "%h:%i:%a";
			$time = time();
		if ($this->form_validation->run() == FALSE)
		{
			?>
			<script type="text/javascript">
			alert("Inputan tidak Valid!!! Ulangi lagi.");			
			</script>
			<?php
			redirect ("blog/detail/".$id_tutorial."");
		}
		else
		{
			$datainput['id_tutorial']=$id_tutorial;
			$datainput['nama']=$nama;
			$datainput['email']=$email;
			$datainput['komentar']=$komentar;
			$datainput['tanggal']=mdate($tgl,$time);;
			$datainput['waktu']=mdate($jam,$time);;
			$this->load->model('Blog_model');
			$this->Blog_model->Simpan_Data($datainput);
			echo "<meta http-equiv='refresh' content='0; url=".base_url()."Blog/detail/".$id_tutorial."'>";
		}
	}
	function pencarian()

	{
		$kata=$this->input->post('katakunci');
		$tabel=$this->input->post('pencarian');
		$this->load->model('Blog_model');
		$data["soal_polling"] = $this->Blog_model->Tampil_Polling();
		$soal_poll = $data["soal_polling"];
		foreach($soal_poll->result() as $soal)
			{
				$id_soal=$soal->id_soal_poll;
			}
		
		$data["pilihan"] = $tabel;
		$data["kata"] = $kata;
		$data["hasil"] = $this->Blog_model->Pencarian($kata,$tabel);
		$data["jumlah"] = $data["hasil"]->num_rows;
		$data["jawaban_polling"] = $this->Blog_model->Tampil_Soal_Polling($id_soal);
		$data["kategori_download"] = $this->Blog_model->Daftar_Kategori_Download();
		$data["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();
		$data["tutorial_populer"] = $this->Blog_model->Tutorial_Populer();
		$this->load->view('e-Blog/bg_header');
		$this->load->view('e-Blog/bg_menu',$data);
		$this->load->view('e-Blog/bg_kiri',$data);
		$this->load->view('e-Blog/hasil_pencarian',$data);
		$this->load->view('e-Blog/bg_kanan',$data);
		$this->load->view('e-Blog/bg_footer');
	}
	
//==============================================================Fungsi Captcha====================================================
  	function _make_captcha()

  	{

		 $this->load->helper( 'captcha' );
		 $vals = array(
     	 'img_path' => './captcha/', // PATH for captcha ( *Must mkdir (htdocs)/captcha )
   	 	 'img_url' => base_url().'captcha/', // URL for captcha img
    	 'img_width' => 150, // width
   	   	 'img_height' => 50, // height
         'expiration' => 7200 ,
  		 );
    		// Create captcha
			 $cap = create_captcha( $vals );
			// Write to DB
			if ( $cap ) {
		 	 $data = array(
				'captcha_id' => '',
				'captcha_time' => $cap['time'],
				'ip_address' => $this -> input -> ip_address(),
				'word' => $cap['word'] ,
				);
		 	 $query = $this -> db -> insert_string( 'captcha', $data );
		 	 $this -> db -> query( $query );
			}else {
			  return "Umm captcha not work" ;
			}
			return $cap['image'] ;
  	}

  	function _check_capthca()

  	{
    	// Delete old data ( 2hours)
    	$expiration = time()-7200 ;
    	$sql = " DELETE FROM captcha WHERE captcha_time < ? ";
    	$binds = array($expiration);
    	$query = $this->db->query($sql, $binds);

    	//checking input
    	$sql = "SELECT COUNT(*) AS count FROM captcha WHERE word = ? AND ip_address = ? AND captcha_time > ?";
    	$binds = array($_POST['captcha'], $this->input->ip_address(), $expiration);
    	$query = $this->db->query($sql, $binds);
    	$row = $query->row();

  		if ( $row -> count > 0 )
    	{
      		return true;
    	}
    	return false;

  	}
//==============================================================Selesai Fungsi Captcha====================================================

}