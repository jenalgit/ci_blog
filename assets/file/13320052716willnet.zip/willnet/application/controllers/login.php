<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		session_start();
	}

	function index()

	{
		$this->load->view('template/signin/index');
	}
	
	function lognin()

	{
		$username = mysql_real_escape_string($this->input->post('usernameteks'));
		$pwd 	  = mysql_real_escape_string($this->input->post('passwordteks'));
		$this->load->model('Blog_model');
		$hasil = $this->Blog_model->Data_Login($username,$pwd);
		
		if (!ctype_alnum($username) OR !ctype_alnum($pwd)){
				?>
				<script type="text/javascript">
				alert("Protected Mbloo....!!!");	
				</script>
				<?php
				redirect('blog');
			}
			
		else if (count($hasil->result_array())>0){
			foreach($hasil->result() as $items){
				$session_username=$items->username."|".$items->nama."|".$items->idlink."|".$items->status;
				$tanda=$items->status;
			}
			$_SESSION['username_belajar']=$session_username;
			if($tanda=="admin")
			{
				redirect('admin');
			}
			else {
			redirect('blog');
			}
		}
		else{
			?>
			<script type="text/javascript">
			alert("Username & Password Wrong.!!!");			
			</script>
			<?php
			redirect('login');
		}
	}
	
	function logout()
	{
	session_destroy();
	redirect('welcome');
	}
}