<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Contact extends CI_Controller {
	
	function __construct()

	{
		parent::__construct();
		session_start();
	}

	function index()

	{
		$this->load->model('Blog_model');
		$data["title"] = "Contact - Design.willnethosting.com";
		$data["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();

		$this->load->view('template/header',$data);
		$this->load->view('template/contact');
		$this->load->view('template/footer');
	}

	function send()

	{

		$datestring = "%d-%m-%Y | %h:%i:%a";
		$time = time();
		$input=array();
		$input['nama']=$this->input->post('nama');
		$input['email']=$this->input->post('email');
		$input['waktu']=mdate($datestring,$time);
		$input['pesan']=$this->input->post('pesan');
		if($input['pesan']==""){
		?>
			<script type="text/javascript">
			alert("Kolom pesan dan subjek belum diisi semua...!!!");			
			</script>
		<?php
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."contact'>";
		}
		else{
		$this->load->model('Blog_model');
		$data["title"] = "Terima kasih - Blog Yudi Purwanto";
		$data["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();
		$this->Blog_model->Contact($input);

		$this->load->view('template/header',$data);
		$this->load->view('template/send');
		$this->load->view('template/footer');
		}
		
	}
}