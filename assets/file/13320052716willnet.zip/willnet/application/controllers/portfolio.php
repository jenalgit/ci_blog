<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Portfolio extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model("Blog_model");
		session_start();
	}

	function index()
	{
		$data=array();
		$this->load->library('Pagination');
		$data["title"] = "Portfolio - Design.willnethosting.com";
		$data["portfolio"] = $this->Blog_model->Tampil_Portfolio();
		$data["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();

		$this->load->view('template/header',$data);
		$this->load->view('template/portfolio',$data);
		$this->load->view('template/footer');
	}
}