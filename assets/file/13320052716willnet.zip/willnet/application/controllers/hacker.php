<?php
class Hacker extends Ci_Controller {

	function __construct()
	{
		parent::__construct();
	}
	
	function index()
	{
		$datestring = "Login : %d-%m-%Y pukul %h:%i %a";
		$time = time();
		$data = array();
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nama"]=$pecah[1];
		}
		$data["tanggal"] = mdate($datestring, $time);
		$this->load->view('dosen/hacker',$data);
	}
	
	function admin()
	{
		
		$session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
		if($session!=""){
		$pecah=explode("|",$session);
		$data["nim"]=$pecah[0];
		$data["nama"]=$pecah[1];
		}

		$this->load->view('dosen/hacker-1',$data);
	}
}
?>
