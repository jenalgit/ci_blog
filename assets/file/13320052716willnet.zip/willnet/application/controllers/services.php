<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Services extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		session_start();
	}

	function index()
	{	
		$this->load->model('Blog_model');
		$data["title"] = "Services - Design.willnethosting.com";
		$data["kategori_tutorial"] = $this->Blog_model->Daftar_Kategori_Tutorial();

		$this->load->view('template/header',$data);
		$this->load->view('template/service');
		$this->load->view('template/footer');
	}
}