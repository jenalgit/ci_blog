    <div class="blog-button ">
        <div class="content">
            <a href="index-2.html">Home</a>
            -
            <a href="about-us.html" class="active">About us</a>
        </div>
    </div>
    <div class="content clearfix">
    <div class="about-us">
        <div class="who-we-are clearfix">
                <div class="heading">
                    <h5>ABOUT US</h5>
                    <div class="small-line"></div>
                    <div class="clearfix"></div>
                </div>
                <div class="top-img about-img ">

                    <div class="slide">
                        <img src="<?php echo base_url();?>assets/images/IMG_97218.jpg" alt="image"/>
                        <img src="<?php echo base_url();?>assets/images/IMG_97219.png" alt="image"/>
                        <img src="<?php echo base_url();?>assets/images/IMG_04545.jpg" alt="image"/>
                    </div>
                    <div class="slider-arrow">
                        <a href="#" class="next-pic"></a>
                        <a href="#" class="prev-pic"></a>
                    </div>

                </div>
                <?php
                foreach ($about->result_array() as $row) {
                ?>
                <div class="paragraphs clearfix">
                    <p> <?php echo $row['isi'];?></p>
                </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>