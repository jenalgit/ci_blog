<div class='content'>
<?php
 foreach($acak_tutorial->result_array() as $acak)
{
	$isi = substr($acak['isi'],0,80);
	$p_satu = explode(' ',$acak['tanggal']);
	$tgl =explode('-',$p_satu[0]); 
	$bulan = array('Jan','Feb','Mar', 'Apr', 'Mei', 'Jun','Jul','Ags','Sep','Okt', 'Nov','Des');	
   echo "<div class='latest-work'>
            <div class='heading'>
                <h5>LATEST WORK</h5>
                <div class='line'>

                </div>
                <div class='l-arrow-left'>
                    <a href='#'><img src='images/arrow_left.png' alt='arrow'/></a>
                </div>
                <div class='l-arrow-right'>
                    <a href='#'><img src='images/arrow-right.png' alt='arrow'/></a>
                </div>
            </div>
        </div>
        <div class='clearfix'></div>
        
        <div class='l-work'>
          <ul class='work-section' id='latest-work'>
              <li class='work'>
                  <div>
                  		<img src='".base_url()."assets/tutorial/".$acak['gambar']."' width='220' height='165'/>
                      	<div class='img-overlay'><a href='".base_url()."assets/tutorial/".$acak['gambar']."' class='zoom'></a></div>
                      
                  </div>
                  <div class='work-one work-main'>
                      <h4>".$acak['judul_tutorial']."</h4>
                      <h5>".$tgl[2]." ".$bulan[($tgl[1]-1)]."</h5>
                  </div>
                  <div class='work-one work-overlay'>
                      <h4><a href='".base_url()."blog/detail/".$acak['slug']."'>".$acak['judul_tutorial']."</a></h4>
                      <h5>".$tgl[2]." ".$bulan[($tgl[1]-1)]."</h5>
                      <p>".$isi."</p>
                  </div>
              </li>
          </ul>
       </div>";
}
?>
</div>