<div class="blog-button">
        <div class="content">
            <a href="index-2.html">Home</a>
            -
            <a href="services.html" class="active">Services</a>
        </div>
    </div>

<!-- CONTENT -->
    <div class="content">

        <div class="services-contents clearfix">

            <div class="services-section responsive clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:300, repeat: true}">
                <div class="service-text">
                    <h3>Responsive Design</h3>
                    <p>Ipsum dolor sit amet, consectetur adipicing elit. Ut volutpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec pharetra interdum.
                    </p>
                </div>
            </div>
            <div class="services-section application clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:600, repeat: true}">
                <div class="service-text">
                    <h3>Mobile Application</h3>
                    <p>Dolor sit amet, adipicing elit. Ut volutpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec pharetra interdum.
                    </p>
                </div>
            </div>
            <div class="services-section web last clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:900, repeat: true}">
                <div class="service-text">
                    <h3>Web Development</h3>
                    <p>Lorem ipsum dolor sit amet, volutpatit. Ut volutpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec pharetra interdum.
                    </p>
                </div>
            </div>
            <div class="services-section font clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:1200, repeat: true}">
                <div class="service-text">
                    <h3>Font Awesome</h3>
                    <p>Amet, consectetur adipicing elit. Ut volutpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec pharetra interdum.
                    </p>
                </div>
            </div>
            <div class="services-section revolution clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:1500, repeat: true}">
                <div class="service-text">
                    <h3>Revolution Slider</h3>
                    <p>Sit amet, adipicing elit. Ut volutpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec pharetra interdum.
                    </p>
                </div>
            </div>
            <div class="services-section retina last clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:1800, repeat: true}">
                <div class="service-text">
                    <h3>Retina Ready</h3>
                    <p>Dolorem ipsum dolor sit amet, volutpatit. Ut volutpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec pharetra interdum.
                    </p>
                </div>
            </div>
        </div>
        <div class="open-chat clearfix" >
            <p class="clearfix">If you have a question about any services feel free to ask us a question. Or you if you need costomer support, just <span> click on button </span>and type the qestion.</p>
            <div class="chat-button"><a href="<?php echo base_url(); ?>pricing">Pricing</a></div>
        </div>
    </div>