<div class='blog-button'>
        <div class='content'>
            <a href='<?php echo base_url(); ?>'>Home</a>
            -
            <a class='active'>portfolio</a>
        </div>
	</div>
<!-- CONTENT -->
    <div class='content'>
        <!-- Filter -->
        <div class='filter'>
            <div class='my-selector nav' data-option-key='filter'>
                
            </div>
        </div>
        <!-- Filter -->
        <!-- Portfolio-work-->
		
        <ul id='project-eliment'  class='da-thumbs portfolio-work'>
		<?php
		foreach ($portfolio->result() as $row) {
		$judul = substr($row->nama,0,24); 
        $isi = substr($row->isi,0,105);
		$p_satu = explode(' ',$row->tanggal);
		$tgl =explode('-',$p_satu[0]); 
		$bulan = array('Jan','Feb','Mar', 'Apr', 'Mei', 'Jun','Jul','Ags','Sep','Okt', 'Nov','Des');
		?>
            <li class='work small-img item web-design'>
                <div>
                	<a href='#'><img src='<?php echo base_url(); ?>assets/portfolio/<?php echo $row->gambar; ?>' width='300' height='225' alt='arrow'/></a>
                	<div class='img-overlay'>
                        <a href='<?php echo base_url(); ?>assets/portfolio/<?php echo $row->gambar; ?>' class='zoom'></a>
                    </div>
                </div>
                <div class='work-one'>
                    <h4><?php echo $judul; ?></h4>
                    <h5><?php echo $tgl[2]; ?> <?php echo $bulan[($tgl[1]-1)]; ?></h5>
                </div>
                <div class="work-one work-overlay">
                      <h4><?php echo $judul; ?></h4>
                      <h5><?php echo $tgl[2]; ?> <?php echo $bulan[($tgl[1]-1)]; ?></h5>
                      <p><?php echo $isi; ?></p>
                  </div>
            </li>
		<?php
		  }
		?>
		</ul>
        <div class='clearfix'></div>

        <div class='pages portfolio-pages'>
               <!-- <?=$paginator;?>-->
        </div>
    </div>