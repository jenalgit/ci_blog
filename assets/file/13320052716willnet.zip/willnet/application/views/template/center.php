<div class="content">
    <div class="service clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:300, repeat: true}">
            
            <div class="responsive-design service-contents">
                <span class="responsive-icon"></span>
                <div class="text"><h3>Responsive Design</h3>
                    <p>Merupakan layanan dan service kami dalam memberikan desain yang responsive
                        yang merupakan nilai penting dalam sebuah website.</p>
                    <a href="<?php echo base_url(); ?>services" >Read More</a>
                </div>
			 </div>
            <div class="mobile-app service-contents" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:600, repeat: true}">
                <span  class="app-icon"></span>
                <div class="text"> 
                	<h3>Mobile Application</h3>
                    <p>Ipsum dolor sit amet, consectetur adipicing elit. Ut volutpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec lorem ipsumom interdum.</p>
                    <a href="<?php echo base_url(); ?>services">Read More</a>
                </div>
			</div>
            <div class="web-development  service-contents last" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:900, repeat: true}">
                <span class="web-icon"></span>
                <div class="text"><h3>Web Development</h3>
                    <p>Web Development kami sangatlah profesional dalam mengerjakan pekerjaannya dalam menyelesanikan tepat pada waktu yang ditentukan.</p>
                    <a href="<?php echo base_url(); ?>services">Read more</a>
              </div>
			</div>
        </div>

        <!-- services -->
        <div class="latest-work">
            <div class="heading">
                <h5>LATEST WORK</h5>
                <div class="line"></div>
                <div class="l-arrow-left"><a href="#"><img src="<?php echo base_url(); ?>assets/images/arrow_left.png" alt="arrow"/></a></div>
                <div class="l-arrow-right"><a href="#"><img src="<?php echo base_url(); ?>assets/images/arrow-right.png" alt="arrow"/></a></div>
            </div>
        </div>
        
        <div class="clearfix"></div>
        
        <ul class="work-section" id="latest-work">
        <?php
        foreach ($portfolio->result() as $row) {
        $judul = substr($row->nama,0,24); 
        $isi = substr($row->isi,0,105);
        $p_satu = explode(' ',$row->tanggal);
        $tgl =explode('-',$p_satu[0]); 
        $bulan = array('Jan','Feb','Mar', 'Apr', 'Mei', 'Jun','Jul','Ags','Sep','Okt', 'Nov','Des');
        ?>
              <li class="work">
                  <div>
                      <img src="<?php echo base_url(); ?>assets/portfolio/<?php echo $row->gambar; ?>" width="220" height="165" alt="arrow"/>
                        <div class="img-overlay"><a href="<?php echo base_url(); ?>assets/portfolio/<?php echo $row->gambar; ?>" class="zoom"></a></div>
                      
                  </div>
                  <div class="work-one work-main">
                      <h4><?php echo $judul; ?></h4>
                      <h5><?php echo $tgl[2]; ?> <?php echo $bulan[($tgl[1]-1)]; ?></h5>
                  </div>
                  <div class="work-one work-overlay">
                      <h4><?php echo $judul; ?></h4>
                      <h5><?php echo $tgl[2]; ?> <?php echo $bulan[($tgl[1]-1)]; ?></h5>
                      <p><?php echo $isi; ?></p>
                  </div>
                  
              </li>
              <?php
              }
              ?>
          </ul>