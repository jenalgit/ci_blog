<div class="clearfix"></div>
    <!-- SLIDER -->

    <div class="blog-button">
        <div class="content">
            <a>Home</a>
            -
            <a class="active">Welcome</a>
        </div>

    </div>
	<div class="content">
        <!-- Side-Bar -->
        <aside>
            <div class="categories">
                <div class="heading clearfix">
                    <h5>RANDOM POSTS</h5>
                    <div class="small-line"></div>
                </div>
                <!-- services -->
            <div class='services'>
              <div id='accordion'>
				<?php
					foreach($acak_tutorial->result_array() as $tut)
					{
					$acak = substr($tut['isi'],0,85);
					$jdl = substr($tut['judul_tutorial'],0,25);
					echo "
                    <h3>".$jdl."</h3>
                    <div>
                        <div class='product-detail'>
							<img src='".base_url()."assets/tutorial/".$tut['gambar']."' width='131' height='81' alt='photo'/>
                            <p>".$acak."<a href='".base_url()."blog/detail/".$tut['slug']."'>Read more<span></span></a></p>
                        </div>
                    </div>";
					}
					?>
                </div>
            </div>
            </div>
            <div class="cloud">
                <div class="heading clearfix">
                    <h5>CATEGORY</h5>
                    <div class="small-line"></div>
                </div>
                <div class="cloud-links">
                <?php
                foreach($kategori_tutorial->result() as $daftar)
                   {
                  $kat = (stripslashes(strip_tags(htmlspecialchars($daftar->id_kategori_tutorial))));
                ?>
                    <div class="links"><a href="<?php echo base_url(); ?>blog/category/<?php echo $kat; ?>"><?php echo $daftar->nama_kategori; ?></a></div>
                <?php
                }
                ?>
                 </div>
            </div>
            <div class="achive">
                <div class="heading clearfix">
                    <h5>POPULAR</h5>
                    <div class="small-line"></div>
                        <a class="year-link"><?php echo date('Y'); ?></a>
                    </div>
                <div class="calender">
                    <ul>
					<?php
					foreach($tutorial_populer->result_array() as $pop)
					{
					$pop_tutorial = substr($pop['judul_tutorial'],0,25);
                     echo "<li><a href=".base_url()."blog/detail/".$pop['slug'].">".$pop_tutorial."<span>(".$pop['counter'].")</span></a></li>";
					}
					?>
                    </ul>
                </div>
            </div>
           
        </aside>
        <!-- Side-Bar -->