<div class="blog-button contact-blog-button">
        <div class="content">
            <a href="<?php echo base_url(); ?>">Home</a>
            -
            <a class="active">Thanks You</a>
        </div>

    </div>


        <div class="map">
        <iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" font size='2' face='arial' align='center'>Pesan anda telah terkirim.<br><b>Terima kasih</b></font></iframe>

        <!-- src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Envato+Pty+Ltd,+13%2F2+Elizabeth+Street,+Melbourne+VIC,+Australia&amp;aq=0&amp;oq=envato&amp;sll=37.0625,-95.677068&amp;sspn=39.371738,86.572266&amp;ie=UTF8&amp;hq=Envato+Pty+Ltd,+13%2F2+Elizabeth+Street,&amp;hnear=Melbourne+Victoria,+Australia&amp;t=p&amp;ll=-37.817209,144.961681&amp;spn=0.010849,0.04107&amp;z=15&amp;output=embed"> -->
        </div>