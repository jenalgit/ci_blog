<!doctype html>
<!--[if IE 7]>    <html class="ie7" > <![endif]-->
<!--[if IE 8]>    <html class="ie8" > <![endif]-->
<!--[if IE 9]>    <html class="ie9" > <![endif]-->
<!--[if IE 9]>    <html class="ie10" > <![endif]-->
<!--[if IE 9]>    <html class="ie11" > <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en-US"> <!--<![endif]-->

<head>
    <title><?php echo $title; ?></title>
	<!-- META TAGS -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width" />
	<meta name="keywords" content="design, design willnet hosting, jasa pembuatan website" />
	<meta itemprop="name" content="Design.willnethosting.com - Kami merupakan perusahaan jasa pelayanan atau pembuatan website.">
	<meta itemprop="description" content="Design.willnethosting.com - Kami merupakan perusahaan jasa pelayanan atau pembuatan website.">
    <meta name="author" content="Yudi Purwanto">

    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/responsive.css" >
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
 	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/prettyPhoto.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/uikit.css" media="screen" />
    
    <!-- REVOLUTION BANNER CSS SETTINGS -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/rs-plugin/css/settings.css" media="screen" />
    
	
    <link rel="shortcut icon" href="images/favicon.html">
				
				<!--[if lt IE 9]>
					<script src="js/html5shiv.js"></script>
				<![endif]-->
</head>
<body>
<!-- HEADER -->
    <header>
             <div class="header-one clearfix">
                <div class="container">
                    <section class="social-icon">
                        <a href="#" class="vimeo" data-uk-scrollspy="{cls:'uk-animation-fade', delay:300, repeat: true}"></a>
                        <a href="#" class="twitter" data-uk-scrollspy="{cls:'uk-animation-fade', delay:400, repeat: true}"></a>
                        <a href="#" class="behance" data-uk-scrollspy="{cls:'uk-animation-fade', delay:500, repeat: true}"></a>
                        <a href="#" class="dribble" data-uk-scrollspy="{cls:'uk-animation-fade', delay:600, repeat: true}"></a>
                        <a href="#" class="skype" data-uk-scrollspy="{cls:'uk-animation-fade', delay:700, repeat: true}"></a>
                        <a href="#" class="facebook" data-uk-scrollspy="{cls:'uk-animation-fade', delay:800, repeat: true}"></a>
                        <a href="#" class="linkedin" data-uk-scrollspy="{cls:'uk-animation-fade', delay:900, repeat: true}" ></a>
                        <a href="#" class="rss" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1000, repeat: true}"></a>
                        <a href="#" class="youtube" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1100, repeat: true}"></a>
                        <a href="#" class="pinterest" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1200, repeat: true}"></a>
                        <a href="#" class="google" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1300, repeat: true}"></a>
                    </section>
                    <div class="registration">
                        <div class="language-section" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1400, repeat: true}">
                            <div class="eng"><a href="#">Indonesia</a></div>
                        </div>
                        <div class="saprator" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1500, repeat: true}"></div>
                        <div class="phone" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1500, repeat: true}"><h6>085-735-832-042</h6></div>
                        <div class="saprator" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1600, repeat: true}"></div>
                        <?php
                        $session=isset($_SESSION['username_belajar']) ? $_SESSION['username_belajar']:'';
                        if($session!=""){
                        $pecah=explode("|",$session);
                        ?>
                        <div class="sign-in" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1700, repeat: true}"><a href="<?php echo base_url(); ?>login/logout">Log Out</a></div>
                        <?php
                        } else{
                        ?>
                        <div class="sign-in" data-uk-scrollspy="{cls:'uk-animation-fade', delay:1700, repeat: true}"><a href="<?php echo base_url(); ?>login">Sign in</a></div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>

            <div class="header-two">
                <div class="container">
                    <div class="menu">
                    <!--<a class="logo" href="index-2.html"> <img src="images/logo.png" alt=""/></a> -->
                    <nav>
                        <ul>
                            <li class="drop-down active"><a href="<?php echo base_url(); ?>">HOME</a>
                            </li>
                            <li class="drop-down active"><a href="<?php echo base_url(); ?>about" >ABOUT</a>
                            </li>
                            <li class="drop-down active"><a href="<?php base_url(); ?>portfolio">PORTFOLIO</a>
                            </li>
                            <li class="drop-down active"><a href="<?php base_url(); ?>services">SERVICES</a>
                            	<ul class="pop-up">
                                    <li><a href="<?php base_url(); ?>pricing">Package</a></li>
                                 </ul>
                            </li>
                            <li class="drop-down active"><a href="<?php echo base_url(); ?>blog">BLOG</a>
                            </li>
                            <li class="drop-down active"><a href="contact">CONTACTS</a></li>
                        </ul>
                    </nav>
                </div>
                </div>
            </div>
            <div class="responsive-nav">
                        <ul>
                            <li class="open">
                                <a href="<?php echo base_url(); ?>">HOME</a>
                                <ul>
                                    <li><a href="<?php echo base_url(); ?>">HOME</a></li>
                                    <li><a href="<?php echo base_url(); ?>about" >ABOUT</a></li>
                                    <li><a href="<?php echo base_url(); ?>portfolio">PORTFOLIO</a></li>
                                    <li><a href="<?php echo base_url(); ?>services">SERVICES</a></li>
                                    <li><a href="<?php echo base_url(); ?>blog">BLOG</a></li>
                                    <li><a href="<?php echo base_url(); ?>contact">CONTACTS</a></li>
                                </ul>
                            </li>

                        </ul>
                    </div>
    </header>