<!-- Blog-post -->
<?php
foreach($tampil_tutorial->result_array() as $tutorial)
{
$isi_tutorial = substr($tutorial['isi'],0,250);

$p_satu = explode(' ',$tutorial['tanggal']);
$tgl =explode('-',$p_satu[0]); 
$bulan = array('Jan','Feb','Mar', 'Apr', 'Mei', 'Jun','Jul','Ags','Sep','Okt', 'Nov','Des');

      echo "<div class='post'>
            <div class='icons'>
                <div class='date clearfix'>
                    <h3>".$tgl[2]."<br>".$bulan[($tgl[1]-1)]."</h3>
                </div>
                <div class=' comments clearfix'>
                    <h3>14</h3>
                </div>
                <div class='reply'>
                    <a href='".base_url()."blog/category/".$tutorial['id_kategori_tutorial']."'>".$tutorial['nama_kategori']."</a>
                </div>
            </div>
            <div class='photo'>
                <a href='".base_url()."blog/detail/".$tutorial['slug']."'><img src='".base_url()."assets/tutorial/".$tutorial['gambar']."' width='540' height='304' alt='post-photo'/></a>
            	<a href='".base_url()."assets/tutorial/".$tutorial['gambar']."' class='zoom-icon zoom'></a>
            </div>
            
            <div class='clearfix'></div>
            <div class='post-footer'>
                <h4 class='admin'>By <a href='#'>Admin</a></h4>
                <h4 class='trip'>In <a href='#'>Photo,</a><a href='#'>Trip,</a><a href='#'>Travel,</a><a href='#'>Dominicana,</a><a href='#'>Information</a></h4>
            </div>
            <div class='interface'>
                <a href='".base_url()."blog/detail/".$tutorial['slug']."'><h3>".$tutorial['judul_tutorial']."</a></h3>
                <p>".$isi_tutorial."...<a href='".base_url()."blog/detail/".$tutorial['slug']."'>Read more<span></span></a></p>
            </div>
        </div>";
}
?>
<!-- Blog-post -->
    <div class='clearfix'></div>
  </div>
</div>
