<div class="blog-button contact-blog-button">
        <div class="content">
            <a href="index-2.html">Home</a>
            -
            <a href="contactus.html" class="active">Contacts</a>
        </div>

    </div>


        <div class="map">
            <!-- <a href="#"><img src="images/map.png" alt="map"/></a> -->
           <iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Envato+Pty+Ltd,+13%2F2+Elizabeth+Street,+Melbourne+VIC,+Australia&amp;aq=0&amp;oq=envato&amp;sll=37.0625,-95.677068&amp;sspn=39.371738,86.572266&amp;ie=UTF8&amp;hq=Envato+Pty+Ltd,+13%2F2+Elizabeth+Street,&amp;hnear=Melbourne+Victoria,+Australia&amp;t=p&amp;ll=-37.817209,144.961681&amp;spn=0.010849,0.04107&amp;z=15&amp;output=embed"></iframe>

        </div>
	<!-- CONTENT -->

    <div class="content clearfix">
        <div class="contact">
            <div class="leave-comment">
                <div class="heading">
                    <h5>SEND US A MESSAGE</h5>
                    <div class="small-line"></div>
                    <div class="clearfix"></div>
                </div>
                <div class="form-area clearfix">
                <form method="post" action="<?php echo base_url(); ?>contact/send">
                    <input type="text" name="nama" placeholder="Name*" class="name" required/>
                    <input type="text" name="email" placeholder="E-mail*" class="last" required/>
                    <div class="clearfix"></div>
                    <textarea name="pesan" placeholder="Message*" class="clearfix" required></textarea>
                    <div class="submit clearfix">
                        <input type="submit" value="Send Message">
                    </div>
                    </form>
                </div>
            </div>
            <aside class="contact-sidebar">

                <div class="heading">
                    <h5>CONTACT INFORMATION</h5>
                    <div class="small-line"></div>
                    <div class="clearfix"></div>
                </div>
                <ul>
                    <li>
                        <h4>MAIN OFFICE</h4>
                        <p>PO Box 90066</p>
                        <p>Westdale, Los Angeles, Ca
                            Santa Monica blvd., 39923</p>
                        <p>E-mail: <a href="#">office@nuelement.com</a></p>
                        <p>Phone: 310 172 5634</p>
                    </li>
                    <li>
                        <h4>SUPPORT TEAM</h4>
                        <p>E-mail: <a href="#">support@nuelement.com</a></p>
                        <p>Phone: 310 172 5634</p>
                    </li>
                    <li class="last">
                        <h4>RECRUITMENT DIVISION</h4>
                        <p>E-mail: <a href="#">job@nuelement.com</a></p>
                        <p>Phone: 310 172 5634</p>
                    </li>
                </ul>
            </aside>
            <div class="clearfix"></div>
            <div class="open-chat clearfix">
                
            </div>
        </div>

    </div>