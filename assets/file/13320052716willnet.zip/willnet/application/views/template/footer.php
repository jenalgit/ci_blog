<!-- Footer-top -->
    <div class="clearfix"></div>
        <div class="footer-top">
            <div class="content">
                <div class="fliker-photo widget">
                    <h3>Flickr Photos</h3>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/IMG_03515.jpg" alt="fliker photo"/></a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/IMG_73204.jpg" alt="fliker photo"/></a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/IMG_86425.jpg" alt="fliker photo"/></a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/DSC_54385.jpg" alt="fliker photo"/></a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/IMG_80685.jpg" alt="fliker photo"/></a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/IMG_73205.jpg" alt="fliker photo"/></a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/IMG_06555.jpg" alt="fliker photo"/></a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/IMG_97215.jpg" alt="fliker photo"/></a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/IMG_86065.jpg" alt="fliker photo"/></a>
                </div>
                <div class="latest-tweets widget">
                    <h3>Latest Tweets</h3>
                    <p class="user-one"><span><a href="#">@user1:</a></span>Cras non ligula at augue interdum imperdiet in fermentum massa.<br>
                    <Span CLASS="time">about 2 hours ago</Span></p>
                    <p><span><a href="#"> @user2:</a></span>Maecenas et tortor nulla, eget gravida est. Maecenas nec lacus id diam adipiscing sodales.<br>
                    <Span CLASS="time">about 2 hours ago</Span></p>
                </div>
                <div class="stay-in-touch widget">
                    <h3>Stay In Touch</h3>
                    <input type="text" name="touch" placeholder="Type your E-mail" />
                    <a href="#">Sign Up</a>
                    <p>* We don't share your E-mail to third person</p>
                </div>
                <div class="contact-us ">
                    <h3>Contact Us</h3>
                    <span class="address">Address:</span>
                    <p>PO Box 90066<br>Wesdale, Los Angeles, CA<br>Santa Monica blvd., 39923</p>
                  <div class="email-section">
                    <span class="email">E-mail:</span>
                    <a href="mailto:purwantoyudi42@gmail.com">purwantoyudi42@gmail.com</a>
                  </div>
                    <span class="phone">Phone:</span>
                    <p>+62 857 35 832042<br>+1 310 252 125783</p>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
	<!-- Footer-top -->

	<!-- Footer -->
         <footer>
            <div class="clearfix"></div>
                <div class="content">
                    <p class="paragraph"> © 2014 Design.willnethosting.com. All Rights Reserved. </p>
                    <ul>
                        <li><a href="<?php echo base_url(); ?>">Home</a><span>/</span></li>
                        <li><a href="<?php echo base_url(); ?>services">Services</a><span>/</span></li>
                        <li><a href="<?php echo base_url(); ?>portfolio">Portfolio</a><span>/</span></li>
                        <li><a href="<?php echo base_url(); ?>blog">Blog</a><span>/</span></li>
                        <li><a href="<?php echo base_url(); ?>contact">Contacts</a></li>
                    </ul>
                </div>
        </footer>
	<!-- Footer -->
	<script src="<?php echo base_url(); ?>assets/js/jquery-1.7.1.min.js"></script>


	<!-- jQuery REVOLUTION Slider  -->
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>


	<script src="<?php echo base_url(); ?>assets/js/uikit.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.appear.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.cycle.all.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery-ui-1.10.3.custom.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.carouFredSel-6.0.4-packed.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.prettyPhoto.js"></script>	
    <script src="<?php echo base_url(); ?>assets/js/jquery.isotope.min.js"></script>
	<script type="text/javascript">
								
				var tpj=jQuery;
				tpj.noConflict();
				
				tpj(document).ready(function() {
				
				if (tpj.fn.cssOriginal!=undefined)
					tpj.fn.css = tpj.fn.cssOriginal;

					tpj('.fullwidthbanner').revolution(
						{	
							delay:9000,												
							startwidth:890,
							startheight:400,
							
							onHoverStop:"on",						// Stop Banner Timet at Hover on Slide on/off
							
							thumbWidth:100,							// Thumb With and Height and Amount (only if navigation Tyope set to thumb !)
							thumbHeight:50,
							thumbAmount:4,
							
							hideThumbs:200,
							navigationType:"both",					//bullet, thumb, none, both	 (No Shadow in Fullwidth Version !)
							navigationArrows:"verticalcentered",		//nexttobullets, verticalcentered, none
							navigationStyle:"round",				//round,square,navbar
							
							touchenabled:"on",						// Enable Swipe Function : on/off
							
							navOffsetHorizontal:0,
							navOffsetVertical:20,
							
							fullWidth:"on",
							
							shadow:0								//0 = no Shadow, 1,2,3 = 3 Different Art of Shadows -  (No Shadow in Fullwidth Version !)
														
						});	
					
			});
	</script>
	<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>																																								

</body>
</html>