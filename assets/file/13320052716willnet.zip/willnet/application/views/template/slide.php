<div class="fullwidthbanner-container">
        <div class="fullwidthbanner">
          <ul>
            
            <!-- FADE -->
            <li data-transition="fade" data-slotamount="10" data-thumb="<?php echo base_url(); ?>assets/images/slider-bg.png"> <img src="<?php echo base_url(); ?>assets/images/slider-bg.png" alt="" />
              <div class="caption lfb" data-x="10" data-y="101" data-speed="1000" data-start="1000" data-easing="easeOutBack"><img src="<?php echo base_url(); ?>assets/images/I_am.png" alt="" /></div>
              
              <div class="caption lfl" data-x="175" data-y="58" data-speed="800" data-start="1800" data-easing="easeOutBack">
                <div class="headings clearfix">
                    <h4>User interface in web <span>Best solution</span><span class="interface-notes"></span></h4>
                 </div>
              </div>
              <div class="caption lfl" data-x="220" data-y="140" data-speed="800" data-start="2000" data-easing="easeOutBack">
                <div class="headings clearfix">
                    <h4>Web Development <span>Best Solution & Hints</span><span class="interface-settings"></span></h4>
                 </div>
              </div>
              <div class="caption lfl" data-x="265" data-y="222" data-speed="800" data-start="2200" data-easing="easeOutBack">
                <div class="headings clearfix">
                    <h4>Responsive Design <span class="interface-iphone"></span></h4>
                 </div>
              </div>
              <div class="caption lfl" data-x="305" data-y="296" data-speed="800" data-start="2400" data-easing="easeOutBack">
                <div class="headings clearfix">
                    <h4>User interface in web <span>Best Solution</span><span class="interface-light"></span></h4>
                 </div>
              </div>
              
              <h2 class="caption large_black lfl " data-x="485" data-y="100" data-speed="1200" data-start="2200" data-easing="easeOutExpo">design.willnethosting.com</h2>
              <a  href="#" class="caption lfb start" data-x="500" data-y="190" data-speed="1200" data-start="2200" data-easing="easeOutExpo">Program yang mudah dicustom ulang</a>  
              <a  href="#" class="caption lfb start" data-x="500" data-y="220" data-speed="1200" data-start="2400" data-easing="easeOutExpo">Memberikan layanan yang memuaskan</a>  
              <a  href="#" class="caption lfb start" data-x="500" data-y="250" data-speed="1200" data-start="2600" data-easing="easeOutExpo">Kepuasan Anda sebagai motivasi kami</a>  
              <a  href="#" class="caption lfb start" data-x="500" data-y="280" data-speed="1200" data-start="2800" data-easing="easeOutExpo">Fitur Fitur yang pastinya susuai keinginan client</a>  
              <a  href="#" class="caption lfb start" data-x="500" data-y="310" data-speed="1200" data-start="3000" data-easing="easeOutExpo">Kerja sama Anda akan terjalin dengan baik dengan kami</a>  
            
            </li>
            <!-- FADE-->
            <li data-transition="fade" data-slotamount="10" data-thumb="<?php echo base_url(); ?>assets/images/slider-bg.png"> <img src="<?php echo base_url(); ?>assets/images/slider-bg.png" alt="" />
              <div class="caption lfl" data-x="10" data-y="50" data-speed="1000" data-start="1000" ><img src="<?php echo base_url(); ?>assets/images/notebook2.png" alt=""  /></div>
              <div class="caption sfr start arrows" data-x="20" data-y="30" data-speed="1200" data-start="1200" ></div>
              <div class="caption lfb start" data-x="400" data-y="30" data-speed="1200" data-start="1600"><img src="<?php echo base_url(); ?>assets/images/page3.png" alt=""></div>
              <div class="caption lfl" data-x="520" data-y="50" data-speed="1200" data-start="1800"><h3>Everything You Need for Your Business</h3></div>
              <div class="caption lfb" data-x="450" data-y="80" data-speed="1200" data-start="1900"><img src="<?php echo base_url(); ?>assets/images/page2.png" alt=""></div>
              <div class="caption lfl" data-x="580" data-y="100" data-speed="1200" data-start="2000"><h3>Built on Bootstrap, Metro UI & Retina Ready</h3></div>
              <div class="caption lfb" data-x="495" data-y="140" data-speed="1200" data-start="1900"><img src="<?php echo base_url(); ?>assets/images/page1.png" alt=""></div>
              <div class="caption lfl" data-x="640" data-y="150" data-speed="1200" data-start="2000"><h3>Awesome Sliders</h3></div>
              </li>
            
            
            
            <!-- FADE-->
            
            
          </ul>
        </div>
      </div>