<?php
$nomor=1;
foreach ($judul_kategori->result_array() as $row) {
$d = array ('-','/','\\',',','.','#',':',';','\'','"','[',']','{','}',')','(','|','`','~','!','@','%','$','^','&','*','=','?','+');
$nama_kategori = strtolower(str_replace($d,"",$row['nama_kategori']));
}
?>
<div class='blog-button'>
        <div class='content'>
            <a href='<?php echo base_url(); ?>'>Home</a>
            -
			<a>category</a>
            -
            <a class='active'><?php echo $nama_kategori; ?></a>
        </div>
	</div>
<!-- CONTENT -->
    <div class='content'>
        <!-- Filter -->
        <div class='filter'>
            <div class='my-selector nav' data-option-key='filter'>
                
            </div>
        </div>
        <!-- Filter -->
        <!-- Portfolio-work-->
		
        <ul id='project-eliment'  class='da-thumbs portfolio-work'>
		<?php
		if(count($query->result())>0){
		foreach ($query->result() as $row) {
		$judul = substr($row->judul_tutorial,0,24); 
		$isi_tutorial = substr($row->isi,0,105);
		$p_satu = explode(' ',$row->tanggal);
		$tgl =explode('-',$p_satu[0]); 
		$bulan = array('Jan','Feb','Mar', 'Apr', 'Mei', 'Jun','Jul','Ags','Sep','Okt', 'Nov','Des');
		?>
            <li class='work small-img item web-design'>
                <div class='likes'>
                    <a href='#' class='eye'><?php echo $row->counter; ?></a>
                </div>
                <div>
                	<a href='#'><img src='<?php echo base_url(); ?>assets/tutorial/<?php echo $row->gambar; ?>' width='300' height='225' alt='arrow'/></a>
                	<div class='img-overlay'>
                        <a href='<?php echo base_url(); ?>assets/tutorial/<?php echo $row->gambar; ?>' class='zoom'></a>
                    </div>
                </div>
                <div class='work-one'>
                    <h4><?php echo $judul; ?></h4>
                    <h5><?php echo $tgl[2]; ?> <?php echo $bulan[($tgl[1]-1)]; ?></h5>
                </div>
                <div class='work-one work-overlay'>
                    <h4><a href='<?php echo base_url(); ?>blog/detail/<?php echo $row->slug; ?>'><?php echo $judul; ?></a></h4>
                    <h5><?php echo $tgl[2]; ?> <?php echo $bulan[($tgl[1]-1)]; ?></h5>
                    <p><?php echo $isi_tutorial; ?></p>
                </div>
            </li>
		<?php
			}
		  }
		  else{
		  echo "Sorry, No matching category found.";
		  }
		?>
		</ul>
        <div class='clearfix'></div>

        <div class='pages portfolio-pages'>
                <?=$paginator;?>
        </div>
    </div>