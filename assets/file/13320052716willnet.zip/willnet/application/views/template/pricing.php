    <div class="blog-button">
        <div class="content">
            <a href="index-2.html">Home</a>
            -
            <a href="services.html">Services</a>
            -
            <a href="#" class="active">Responsive Design</a>
        </div>

    </div>

<!-- CONTENT -->
    <div class="content">
        <div class="top-section clearfix">
            <div class="description responsive clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-left', delay:500, repeat: true}">
                <div class="service-text">
                    <h3>Responsive Design</h3>
                    <p class="first">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Utpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec pharetra interdum Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                    <p>Praesent vitae tellus id urna varius laoreet id id dolor. Proin commodo fermentum neque, sit amet varius elit vulputate ultrices. Vestibulum enim nulla, sagittis porta fermentum vel, semper quis nisl. lectus, vel eleifend magna.
                    </p>
                </div>
                <ul>
                    <li>Responsive WordPress Theme</li>
                    <li>Unlimited Options & Styles</li>
                    <li>Fresh & Clean Design</li>
                    <li>Awesome Premium Sliders</li>
                </ul>
            </div>
            <div class="responsive-img clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-right', delay:600, repeat: true}">
                <div class="slide">
                    <img src="<?php echo base_url(); ?>assets/images/IMG_97218.jpg" alt="image"/>
                    <img src="<?php echo base_url(); ?>assets/images/IMG_97219.png" alt="image"/>
                    <img src="<?php echo base_url(); ?>assets/images/IMG_04545.jpg" alt="image"/>
                </div>
                <div class="slider-arrow">
                    <a href="#" class="next-pic"></a>
                    <a href="#" class="prev-pic"></a>
                </div>
            </div>
        </div>
        <div class="pricing-table ">
           <div class="tables clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:700, repeat: true}">
                <div class="table right clearfix">
                    <ul>
                        <li class="table-heading">Silver Package</li>
                        <li>10 Photos</li>
                        <li>No Retouching</li>
                        <li>No Postproduction</li>
                        <li>Love Story, Open Air</li>
                        <li>No Make-up</li>
                        <li>Certificate</li>
                        <li class="price middle">$9.99</li>

                    </ul>
                </div>
                <a href="#" class="purchase"> Purchase</a>
           </div>
            <div class="tables clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:800, repeat: true}">
                <div class="table right clearfix">
                    <ul>
                        <li class="table-heading">Gold Package</li>
                        <li>25 Photos</li>
                        <li>10 Photos with Retouching</li>
                        <li>No Postproduction</li>
                        <li>Love Story, Open Air, Studio</li>
                        <li>No Make-up</li>
                        <li>Certificate</li>
                        <li class="price middle">$19.99</li>

                    </ul>
                </div>
                <a href="#" class="purchase"> Purchase</a>
            </div>
            <div class="tables clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:900, repeat: true}">
                <div class="table right clearfix">
                    <ul>
                        <li class="table-heading">Platinum Package</li>
                        <li>50 Photos</li>
                        <li>20 Photos with Retouching</li>
                        <li>No Postproduction</li>
                        <li>Love Story, Open Air, Night Life</li>
                        <li>Make-up</li>
                        <li>Certificate</li>
                        <li class="price middle">$29.99</li>
                    </ul>
                </div>
                <a href="#" class="purchase"> Purchase</a>
            </div>
            <div class="tables clearfix" data-uk-scrollspy="{cls:'uk-animation-slide-top', delay:1000, repeat: true}">
                <div class="table clearfix">
                    <ul>
                        <li class="table-heading">Diamond Package</li>
                        <li>100 Photos</li>
                        <li>30 Photos with Retouching</li>
                        <li>5 Photos with Postproduction</li>
                        <li>All Purpose</li>
                        <li>Make-up</li>
                        <li>Certificate</li>
                        <li class="price">$49.99</li>
                    </ul>
                </div>
                <div class="clearfix"></div>
                <a href="#" class="purchase"> Purchase</a>
            </div>
        </div>

    </div>