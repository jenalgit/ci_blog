<div class="recent-blog small-recent-blog clearfix">
           <div class="heading">
				<h5>Recent Blog</h5>
                <div class=" small-line"></div>
                <div class="arrow-left"><a href="#"><img src="<?php echo base_url(); ?>assets/images/arrow_left.png" alt="arrow"/></a></div>
                <div class="arrow-right"><a href="#"><img src="<?php echo base_url(); ?>assets/images/arrow-right.png" alt="arrow"/></a> </div>
                <div class="clearfix"></div>
           </div>
           
		   <ul id="blog-sec">
           <?php
            foreach($tampil_tutorial->result_array() as $tutorial)
            {
            $p_satu = explode(' ',$tutorial['tanggal']);
            $tgl =explode('-',$p_satu[0]); 
            $bulan = array('Jan','Feb','Mar', 'Apr', 'Mei', 'Jun','Jul','Ags','Sep','Okt', 'Nov','Des');
            ?>
		   	<li class="big-image">
		   	     <div class="icons clearfix">
		   	         <div class="date clearfix">
		   	             <h3><a href="#"><?php echo $tgl[2]; ?></a> <br><a href="#"><?php echo $bulan[($tgl[1]-1)]; ?></a></h3>
		   	         </div>
		   	     </div>
		   	         
		   	     <div class="blog-image">
		   	         <a href="<?php echo base_url();?>blog/detail/<?php echo $tutorial['slug']; ?>"> <img src="<?php echo base_url(); ?>assets/tutorial/<?php echo $tutorial['gambar']; ?>" width="380" height="214" alt="big image"/></a>
		   	         <h4><?php echo $tutorial['judul_tutorial']; ?></h4>
		   	     </div>
		   	 </li>
              <?php
            }
            ?>
		   </ul>
        </div>
        <!-- recent-blog -->
        
        <!-- Testimonials -->
        <div class="testimonials clearfix">
            <div class="heading">
				<h5>Skill</h5>
                <div class=" small-line"></div>
                <div class="arrow-left te-arrow-left"><a href="#"><img src="<?php echo base_url(); ?>assets/images/arrow_left.png" alt="arrow"/></a></div>
                <div class="arrow-right te-arrow-right"><a href="#"><img src="<?php echo base_url(); ?>assets/images/arrow-right.png" alt="arrow"/></a></div>
                <div class="clearfix"></div>
            </div>
            <ul id="testimonials">
            	<li>
            		<div class="section">
            		    <p>Nama saya Yudi Purwanto, lahir di kediri umur 20 tahun pekerjaan sebagai web development dan saya itu menyukai tantangan dan mencoba hal-hal baru yang menurut saya itu bermanfaat. Ingin tau saya lebih jauh bisa contact email admin@yudi-purwanto.com</p>
            		    <div class="progress-bar">
            		       <div class="bar-section advantage">
            		           <h4>Programming: </h4>
            		           <div class="base"><div class="advantage-bar"></div></div>
            		           <h5>10</h5>
            		       </div>
            		       <div class="bar-section convenience">
            		            <h4>Design: </h4>
            		            <div class="base"><div class="convenience-bar"></div></div>
            		            <h5>8</h5>
            		        </div>
            		        <div class="bar-section benefits last">
            		            <h4>Graphic:</h4>
            		            <div class="base"><div class="benefits-bar"></div></div>
            		            <h5>7</h5>
            		        </div>
            		    </div>
            		    <span></span>
            		</div>
            		<div class="developer">
            		    <a href="#"> <img src="<?php echo base_url(); ?>assets/images/developer-img.png" /></a>
            		    <h4>Yudi Purwanto</h4><br>
            		    <h5>Web Developer</h5>
            		</div>
            	</li>
                <li>
            		<div class="section">
            		    <p>Nama saya Derry Prillian, pekerjaan sebagai web design dan CEO willnethosting.com, merupakan kebanggaan bisa bekerja disini dan bertemu dengan orang" yang profesional. Email admin@willnethosting.com </p>
            		    <div class="progress-bar">
            		       <div class="bar-section advantage">
            		           <h4>Design: </h4>
            		           <div class="base"><div class="advantage-bar"></div></div>
            		           <h5>10</h5>
            		       </div>
            		       <div class="bar-section convenience">
            		            <h4>Graphic: </h4>
            		            <div class="base"><div class="convenience-bar"></div></div>
            		            <h5>8</h5>
            		        </div>
            		        <div class="bar-section benefits last">
            		            <h4>Progamming:</h4>
            		            <div class="base"><div class="benefits-bar"></div></div>
            		            <h5>6</h5>
            		        </div>
            		    </div>
            		    <span></span>
            		</div>
            		<div class="developer">
            		    <a href="#"> <img src="<?php echo base_url(); ?>assets/images/developer-img.png" /></a>
            		    <h4>Derry Prilian</h4><br>
            		    <h5>CEO & Designer</h5>
            		</div>
            	</li>
            </ul>
        </div>
        <!-- Testimonials -->
        
        <!-- Clients -->
        <div class="clearfix"></div>
        <div class="our-clients">
            <div class="heading">
                <h5>OUR CLIENTS</h5>
                <div class="small-line"></div>
                <div class="arrow-left c-arrow-left"><a href="#"><img src="<?php echo base_url(); ?>assets/images/arrow_left.png" alt="arrow"/></a></div>
                <div class="arrow-right c-arrow-right"><a href="#"><img src="<?php echo base_url(); ?>assets/images/arrow-right.png" alt="arrow"/></a></div>
                <div class="clearfix"></div>
            </div>
            <ul class="clients-logo">
            <?php
            foreach ($client->result() as $tam) {
                # code...
           ?>
				<li><a href="#"><img src="<?php echo base_url(); ?>assets/client/<?php echo $tam->gambar; ?>" title="<?php echo $tam->nama; ?>" alt="clients"/></a></li>
            <?php
             }
             ?>
			</ul>
        </div>
        <!-- Clients -->
        
    </div>