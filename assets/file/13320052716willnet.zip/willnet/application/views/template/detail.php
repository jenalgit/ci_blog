<!-- Blog-post -->
<?php
foreach($detail->result_array() as $rows) {
	$d = array ('-','/','\\',',','.','#',':',';','\'','"','[',']','{','}',')','(','|','`','~','!','@','%','$','^','&','*','=','?','+');
	$id_tutorial = strtolower(str_replace($d,"",$rows['slug']));
	$p_satu = explode(' ',$rows['tanggal']);
	$tgl =explode('-',$p_satu[0]); 
	$bulan = array('Jan','Feb','Mar', 'Apr', 'Mei', 'Jun','Jul','Ags','Sep','Okt', 'Nov','Des');
	$isian=nl2br($rows['isi']);
	
	echo "
        <div class='post blog-post'>
            <div class='icons'>
                <div class='date clearfix'>
                    <h3>".$tgl[2]."<br>".$bulan[($tgl[1]-1)]."</h3>
                </div>
                <div class=' comments clearfix'>
                    <h3> <a href='#'>14</a></h3>
                </div>
                <div class='reply'>
                    <a href='".base_url()."blog/category/".$rows['id_kategori_tutorial']."'> ".$rows['nama_kategori']."</a>
                </div>
            </div>
            <div class='photo'>
                <img src='".base_url()."assets/tutorial/".$rows['gambar']."' width='540' height='304' alt='post-photo'/>
            </div>
            <div class='clearfix'></div>
            <div class='post-footer'>
                <h4 class='admin'>By <a href='#'>Admin</a></h4>
                <h4 class='trip'>In <a href='#'>Photo,</a><a href='#'>Trip,</a><a href='#'>Travel,</a><a href='#'>Dominicana,</a> <a href='#'>Information</a></h4>
            </div>
            <div class='interface'>
                <h3>".$rows['judul_tutorial']."</h3>
                <p>".$isian."</p>
                <div class='some-body'>
                    <p>Volutpat rutrum eros sit amet sollicitudin. Suspendisse pulvinar, velit nec pharetra interdum. Rsit amet, atom cosectetur adipiscing now. Volutpat rutrum eros sit amet sollicitudin.  Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <h6>Some Body</h6>
                </div>
            </div>";
			}
			?>
        <!-- Comment-Section -->
            <div class='comment-section'>
                <div class='heading'>
                    <h5>SHARE ON :</h5>
					<div class="tags">
					<p style="text-align:justify;">
					<script language="javascript">
					document.write("<a class='tags' href='https://twitter.com/home/?status=" + document.URL + "' target='_blank'> Twitter</a>  <a href='https://www.facebook.com/share.php?u=" + document.URL + "' target='_blank'> Facebook</a>  <a href='http://www.reddit.com/submit?url=" + document.URL + "' target='_blank'> Reddit</a>  <a href='http://digg.com/submit?url=" + document.URL + "' target='_blank'> Digg</a>");
					</script>
					</p>
					</div>
                    <div class='small-line'></div>
                    <div class='clearfix'></div>
                </div>
				<div id="disqus_thread"></div>
				<script type="text/javascript">
				/* * * CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE * * */
				var disqus_shortname = 'designwillnet'; // required: replace example with your forum shortname

				/* * * DON'T EDIT BELOW THIS LINE * * */
				(function() {
				var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
				dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
				(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
				})();
				</script>
				<noscript>Please enable JavaScript to view the <a href="http://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
				<a href="http://disqus.com" class="dsq-brlink">comments powered by <span class="logo-disqus">Disqus</span></a>
             </div>
          </div>
        </div>
       <!-- Blog-post-->