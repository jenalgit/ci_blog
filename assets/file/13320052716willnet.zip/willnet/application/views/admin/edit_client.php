<div id="bg-isi"><h2>Module Edit Client</h2><br />
<a href="<?php echo base_url(); ?>admin/tambahclient"><div class="pagingpage"><b> + Tambah Client </b></div></a>
<br /><br />
<table width="870" style="border: 1pt ridge #cccccc;" cellpadding="2" cellspacing="1" class="widget-small">
<?php echo form_open_multipart('admin/updateclient');?>
<?php
foreach($det->result_array() as $k)
{
$judul=$k["nama"];
$gambar=$k["gambar"];
$id=$k["id"];
}
?>
<tr><td width="150">Nama</td><td width="10">:</td><td><input type="text" name="judul" class="textfield" size="80" value="<?php echo $judul; ?>"></td></tr>
<tr><td width="150" valign="top"></td><td width="10" valign="top"></td><td><img src="<?php echo base_url(); ?>assets/client/<?php echo $gambar;  ?>" /></td></tr>
<tr><td width="150" valign="top">Gambar</td><td width="10" valign="top">:</td><td><input type="file" name="userfile" class="textfield"> <h3>* Bila gambar tidak diganti, silahkan dikosongkan saja.</h3></td></tr>
<tr><td width="150" valign="top"></td><td width="10" valign="top"></td><td><input type="submit" value="Update" class="tombol"><input type="hidden" name="id" value="<?php echo $id; ?>" /></td></tr>
</form>
</table><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
</div>