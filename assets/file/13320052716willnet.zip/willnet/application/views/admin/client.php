<div id="bg-isi"><h2>Module Client</h2><br />
<a href="<?php echo base_url(); ?>admin/tambahclient"><div class="pagingpage"><b> + Tambah Client </b></div></a>
<br /><br />
<table width="870" bgcolor="#ccc" cellpadding="2" cellspacing="1" class="widget-small">
<tr bgcolor="#FFF" align="center"><td width="30"><strong>No.</strong></td><td><strong>Nama</strong></td><td><strong>Gambar</strong></td><td colspan="2"><strong>Aksi</strong></td></tr>
<?php
$nomor=$page+1;
foreach($query->result() as $b)
{
		if(($nomor%2)==0){
			$warna="#C8E862";
		} else{
			$warna="#D6F3FF";
		}
echo "<tr bgcolor='$warna'><td>".$nomor."</td><td>".$b->nama."</td><td>".$b->gambar."</td><td><a href='".base_url()."admin/editclient/".$b->id."' title='Edit'><img src='".base_url()."assets/images/edit-icon.gif' border='0'></a></td>
<td><a href='".base_url()."admin/hapusclient/".$b->id."' onClick=\"return confirm('Anda yakin ingin menghapus ini?')\" title='Hapus'><img src='".base_url()."assets/images/hapus-icon.gif' border='0'></a></td></tr>";
$nomor++;
}
?>
</table>
<table class="widget" align="center"><tr><td><?=$paginator;?></td></tr></table><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
</div>