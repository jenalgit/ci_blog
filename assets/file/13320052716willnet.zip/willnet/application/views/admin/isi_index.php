<div id="bg-isi"><h2>Selamat Datang di Control Panel Admin - design.willnethosting.com</h2><br />
Selamat datang <b><?php echo $nama; ?></b>, anda Log In dengan username <b><?php echo $nim; ?></b> dan hak akses <b>admin</b>
<br />
<br />
<br />
<br />
<br />
<br />
<br /><br />
<br />
<br />
<br />
<br />
<br />
<br /><br />
<br />
<br />
<br />
<br />
<br />
<br /><br />
<br />
<br />
<br />
<br />
<br />
<br /></div>