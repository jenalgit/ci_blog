<div id="bg-isi"><h2>Module Edit About</h2><br />
<br /><br />
<table width="870" style="border: 1pt ridge #cccccc;" cellpadding="2" cellspacing="1" class="widget-small">
<?php echo form_open_multipart('admin/updateabout');?>
<?php
foreach($det->result_array() as $k)
{
$isi=$k["isi"];
$id=$k["id"];
}
?>
<tr><td width="150" valign="top">Isi</td><td width="10" valign="top">:</td><td><textarea name="isi" cols="65" rows="25" class="textfield"><?php echo $isi; ?></textarea></td></tr>
<tr><td width="150" valign="top"></td><td width="10" valign="top"></td><td><input type="submit" value="Update" class="tombol"><input type="hidden" name="id" value="<?php echo $id; ?>" /></td></tr>
</form>
</table><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
</div>