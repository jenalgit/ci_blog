<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="<?php echo base_url(); ?>assets/css/admin-style.css" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>assets/css/jquery.tagsinput.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.2.0.3.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.slug.js"></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.tagsinput.min.js'></script>
    <script type='text/javascript' src='<?php echo base_url(); ?>assets/js/plugins.js'></script>
  <script type="text/javascript">
    $(document).ready(function () {
        $("#title").slug();
    });
  </script>
<link rel="shortcut icon" href="<?php echo base_url(); ?>application/views/e-learning/images/icon.png" />
<?php echo $scriptmce; ?>
<title>CONTROL PANEL ADMIN - design.willnethosting.com</title>
</head>

<body>
<div id="bg-head"><img src="<?php echo base_url(); ?>assets/images/bg-head.png" /></div>
<div id="bg-isi">
<br /><br>
</div>