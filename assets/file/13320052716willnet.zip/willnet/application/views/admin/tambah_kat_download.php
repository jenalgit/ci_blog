<div id="bg-isi"><h2>Module Kategori Download </h2><br />
<a href="<?php echo base_url(); ?>index.php/admin/tambahupload"><div class="pagingpage"><b> + Tambah File / Upload File</b></div></a>
<a href="<?php echo base_url(); ?>index.php/admin/katdownload"><div class="pagingpage"><b> + Kategori Download</b></div><br /><br /></a>
<?php echo form_open_multipart('admin/simpankatdownload');?>
<table width="520" cellpadding="2" cellspacing="1" class="widget-small">
<tr><td width="150" valign="top">Nama Kategori Download</td><td width="10" valign="top">:</td><td><input type="text" name="nama" class="textfield" size="50" /></td></tr>
<tr><td width="150" valign="top"></td><td width="10" valign="top"></td><td><input type="submit" class="tombol" value="Simpan Nama" /></td></tr>
</table>
</form>
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
</div>