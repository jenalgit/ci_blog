<div id="bg-isi"><h2>Module Tambah </h2><br />
<a href="<?php echo base_url(); ?>admin/tambahportfolio"><div class="pagingpage"><b> + Tambah Portfolio </b></div></a>
<br /><br />
<table width="870" style="border: 1pt ridge #cccccc;" cellpadding="2" cellspacing="1" class="widget-small">
<?php echo form_open_multipart('admin/simpanportfolio');?>
<tr><td width="150">Nama</td><td width="10">:</td><td><input type="text" name="judul" class="textfield" size="80"></td></tr>
<tr><td width="150" valign="top">Isi</td><td width="10" valign="top">:</td><td><textarea name="isi" cols="65" rows="25" class="textfield"></textarea></td></tr>
<tr><td width="150" valign="top">Gambar</td><td width="10" valign="top">:</td><td><input type="file" name="userfile"></td></tr>
<tr><td width="150" valign="top"></td><td width="10" valign="top"></td><td><input type="submit" value="Simpan" class="tombol"></td></tr>
</form>
</table><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
</div>
