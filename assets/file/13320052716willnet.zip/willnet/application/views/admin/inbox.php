<div id="bg-isi"><h2>Module Inbox Pesan </h2><br />
<table width="880" bgcolor="#ccc" cellpadding="1" cellspacing="1" class="widget-small">
<tr bgcolor="#FFF" align="center"><td><strong>No.</strong></td><td><strong>Nama</strong></td><td><strong>Email</strong></td><td><strong>Pesan</strong></td><td><strong>Waktu</strong></td><td><strong>Aksi</strong></td></tr>
<?php
$nomor=$page+1;
if(count($query->result())>0){
foreach($query->result() as $t)
{
		if(($nomor%2)==0){
			$warna="#C8E862";
		} else{
			$warna="#D6F3FF";
		}
$sambung="9002".$t->id_inbox."";
echo "<tr bgcolor='".$warna."'><td align='center'>".$nomor."</td>
<td>".$t->nama."</td>
<td>".$t->email."</td>
<td>".$t->pesan."</td>
<td>".$t->waktu."</td>
<td><a href='".base_url()."index.php/admin/hapusinbox/".base64_encode($sambung)."' onClick=\"return confirm('Anda yakin ingin menghapus file ini?')\" title='Hapus File'><img src='".base_url()."assets/images/hapus-icon.gif' border='0'> Hapus Pesan</a>
</td></tr>";
$nomor++;	
}
}
else{
echo "<tr><td colspan='5'>Inbox Pesan anda masih kosong.</td></tr>";
}
?>
</table><br />
<table class="widget" align="center"><tr><td><?=$paginator;?></td></tr></table><br /><br /><br /><br /><br />
</div>
