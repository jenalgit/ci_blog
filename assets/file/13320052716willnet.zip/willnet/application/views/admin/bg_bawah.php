<div id="menu-bawah"><div id="bg-mn">
<a href="<?php echo base_url(); ?>admin"><div id="bg-mn-kiri"></div><div id="bg-mn-tengah">Beranda</div><div id="bg-mn-kanan"></div></a>
<a href="<?php echo base_url(); ?>admin/portfolio"><div id="bg-mn-kiri"></div><div id="bg-mn-tengah">Portfolio</div><div id="bg-mn-kanan"></div></a>
<a href="<?php echo base_url(); ?>admin/client"><div id="bg-mn-kiri"></div><div id="bg-mn-tengah">Clients</div><div id="bg-mn-kanan"></div></a>
<a href="<?php echo base_url(); ?>admin/about"><div id="bg-mn-kiri"></div><div id="bg-mn-tengah">About</div><div id="bg-mn-kanan"></div></a>
<a href="<?php echo base_url(); ?>admin/tutorial"><div id="bg-mn-kiri"></div><div id="bg-mn-tengah">Tutorial</div><div id="bg-mn-kanan"></div></a>
<a href="<?php echo base_url(); ?>admin/inbox"><div id="bg-mn-kiri"></div><div id="bg-mn-tengah">Inbox</div><div id="bg-mn-kanan"></div></a>
<a href="<?php echo base_url(); ?>login/logout"><img src="<?php echo base_url(); ?>assets/images/logout-icon.png" border="0"/></a>
</div></div>
</body>
</html>
