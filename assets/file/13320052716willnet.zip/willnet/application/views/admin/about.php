<div id="bg-isi"><h2>Module About</h2><br />
<br /><br />
<table width="870" bgcolor="#ccc" cellpadding="2" cellspacing="1" class="widget-small">
<tr bgcolor="#FFF" align="center"><td width="30"><strong>No.</strong></td><td><strong>Isi</strong></td><td colspan="2"><strong>Aksi</strong></td></tr>
<?php
$nomor=+1;
foreach($query->result() as $b)
{
		if(($nomor%2)==0){
			$warna="#C8E862";
		} else{
			$warna="#D6F3FF";
		}
echo "<tr bgcolor='$warna'><td>".$nomor."</td><td>".$b->isi."</td><td><a href='".base_url()."admin/editabout/".$b->id."' title='Edit'><img src='".base_url()."assets/images/edit-icon.gif' border='0'></a></td></tr>";
$nomor++;
}
?>
</table>
</div>