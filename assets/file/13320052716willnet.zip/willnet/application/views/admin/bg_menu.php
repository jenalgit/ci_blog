<div id="bg-isi">
<div id="bg-menu-kiri">
<table class="round" style="border:1pt solid #999999;" width="200" cellpadding="5" cellspacing="2">
<tr><td bgcolor="#9BE2FF"><h3>SUB MENU YANG LAINNYA</h3></td></tr>
<tr><td class="td-hover"><a href="<?php echo base_url(); ?>index.php/admin/katberita">&#8226; Module Kategori Berita</a></td></tr>
<tr><td class="td-hover"><a href="<?php echo base_url(); ?>index.php/admin/kattutorial">&#8226; Module Kategori Tutorial</a></td></tr>
<tr><td class="td-hover"><a href="<?php echo base_url(); ?>index.php/admin/katdownload">&#8226; Module Kategori Download</a></td></tr>
<tr><td class="td-hover"><a href="<?php echo base_url(); ?>index.php/admin/dosen">&#8226; Module Daftar Dosen</a></td></tr>
<tr><td class="td-hover"><a href="<?php echo base_url(); ?>index.php/admin/mhs">&#8226; Module Daftar Mahasiswa</a></td></tr>
<tr><td class="td-hover"><a href="<?php echo base_url(); ?>index.php/admin/matkul">&#8226; Module Mata Kuliah</a></td></tr>
<tr><td class="td-hover"><a href="<?php echo base_url(); ?>index.php/admin/komenberita">&#8226; Module Komentar Berita</a></td></tr>
<tr><td class="td-hover"><a href="<?php echo base_url(); ?>index.php/admin/polling">&#8226; Module Polling</a></td></tr>
</table><br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
</div>