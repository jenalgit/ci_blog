tinyMCE.addI18n('zh.syntaxhl_dlg',{
	title : '用SyntaxHighlighter插入代码',
	highlight_options : '高亮选项',
	paste : '粘贴代码',
	choose_lang : '选择语言',
	nogutter : '无装订线',
	light : '精简模式',
	collapse : '折叠代码',
	fontsize : '字体大小',
	first_line : '起始行的值',
	highlight : '高亮行'
});
