tinyMCE.addI18n('zh.syntaxhl',{
	desc : '用Syntaxhighlighter插入代码'
});
